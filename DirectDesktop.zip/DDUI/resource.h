//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DDUI.rc
//
#define IDR_UIFILE1                     31
#define IDS_STRING133                   133
#define IDS_STRING134                   134
#define IDS_STRING135                   135
#define IDS_STRING136                   136
#define IDS_STRING137                   137
#define IDS_STRING138                   138
#define IDS_STRING139                   139
#define IDS_STRING140                   140
#define IDS_STRING141                   141
#define IDS_STRING142                   142
#define IDS_STRING143                   143
#define IDS_STRING144                   144
#define IDS_STRING145                   145
#define IDS_STRING146                   146
#define IDS_STRING147                   147
#define IDS_STRING148                   148
#define IDS_STRING149                   149
#define IDS_STRING150                   150
#define IDS_STRING151                   151
#define IDS_STRING152                   152
#define IDS_STRING153                   153
#define IDS_STRING154                   154
#define IDS_STRING155                   155
#define IDS_STRING156                   156
#define IDS_STRING157                   157
#define IDS_STRING158                   158
#define IDS_STRING159                   159
#define IDS_STRING160                   160
#define IDS_STRING161                   161
#define IDS_STRING162                   162
#define IDS_STRING163                   163
#define IDS_STRING164                   164
#define IDS_STRING165                   165
#define IDS_STRING166                   166
#define IDS_STRING167                   167
#define IDS_STRING168                   168
#define IDS_STRING169                   169
#define IDS_STRING170                   170
#define IDS_STRING171                   171
#define IDS_STRING172                   172
#define IDS_STRING173                   173
#define IDS_STRING174                   174
#define IDS_STRING175                   175
#define IDS_STRING176                   176
#define IDS_STRING177                   177
#define IDS_STRING178                   178
#define IDS_STRING179                   179
#define IDS_STRING180                   180
#define IDS_STRING181                   181
#define IDS_STRING182                   182
#define IDS_STRING183                   183
#define IDS_STRING200                   200
#define IDS_STRING201                   201
#define IDS_STRING202                   202
#define IDS_STRING203                   203
#define IDS_STRING204                   204
#define IDS_STRING205                   205
#define IDS_STRING206                   206
#define IDS_STRING207                   207
#define IDS_STRING208                   208
#define IDS_STRING209                   209
#define IDS_STRING210                   210
#define IDS_STRING211                   211
#define IDS_STRING212                   212
#define IDS_STRING213                   213
#define IDS_STRING214                   214
#define IDS_STRING215                   215
#define IDS_STRING216                   216
#define IDS_STRING217                   217
#define IDS_STRING218                   218
#define IDS_STRING219                   219
#define IDS_STRING220                   220
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        946
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
