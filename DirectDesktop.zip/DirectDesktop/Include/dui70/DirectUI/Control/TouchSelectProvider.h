#pragma once

namespace DirectUI
{
	
}
