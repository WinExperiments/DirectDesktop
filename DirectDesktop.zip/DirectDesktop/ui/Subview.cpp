#include "pch.h"

#include "Subview.h"
#include "EditMode.h"
#include "..\backend\ContextMenus.h"
#include "..\backend\DirectoryHelper.h"
#include "..\backend\SettingsHelper.h"
#include "..\DirectDesktop.h"
#include <wrl.h>

using namespace DirectUI;
using namespace DDUI;

namespace DirectDesktop
{
    NativeHWNDHost* subviewwnd;
    HWNDElement* subviewparent;
    DUIXmlParser* parserSubview;
    Element* pSubview;
    unsigned long key2 = 0;

    TouchButton* fullscreenpopupbase;
    Element* fullscreenpopupbg;
    DDScalableTouchButton* fullscreeninner;
    TouchButton* centered;
    Element* popupcontainer;
    void* g_tempElem;
    CDropTarget* g_subviewtarget;

    bool g_issubviewopen = false;
    bool g_issettingsopen = false;
    bool g_pendingaction = false;
    bool g_peek = false;
    bool g_focused = false;

    WNDPROC WndProcSubview;
    WNDPROC WndProcSubviewInner;

    // 0.5.8.1: TODO: Better peek listener
    LRESULT CALLBACK TopLevelWindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
    {
        switch (uMsg)
        {
        case WM_DPICHANGED:
        {
            g_lastDpiChangeTick = GetTickCount64();
            UpdateScale();
            SetTimer(wnd->GetHWND(), 10, 1000, nullptr);
            break;
        }
        case WM_DISPLAYCHANGE:
        {
            if (abs((int)(GetTickCount64() - g_lastDpiChangeTick)) > 1500)
            {
                g_ignoreWorkAreaChange = true;
                g_lastWidth = 0, g_lastHeight = 0;
                AdjustWindowSizes(false);
                SetTimer(wnd->GetHWND(), 5, 150, nullptr);
                SetTimer(wnd->GetHWND(), 13, 600, nullptr);
                g_lastDpiChangeTick = GetTickCount64();
            }
            break;
        }
        case WM_CLOSE:
        {
            return 0;
        }
        case WM_CANCELMODE:
        {
            if (!g_peek)
            {
                g_peek = true;
                GTRANS_DESC transDesc[1];
                TransitionStoryboardInfo tsbInfo = {};
                TriggerScaleOut(UIContainer, transDesc, 0, 0.0f, 0.5f, 0.1f, 0.9f, 0.2f, 1.0f, 1.0f, 1.0f, 0.5f, 0.5f, false, false);
                ScheduleGadgetTransitions_DWMCheck(0, ARRAYSIZE(transDesc), transDesc, UIContainer->GetDisplayNode(), &tsbInfo);
                DUI_SetGadgetZOrder(UIContainer, -1);
                if (g_pctx->windowAnim && g_pctx->clientAnim)
                    fullscreenpopupbg->SetVisible(false);
            }
            break;
        }
        case WM_NCHITTEST:
        {
            if (g_peek)
            {
                g_peek = false;
                GTRANS_DESC transDesc[1];
                TransitionStoryboardInfo tsbInfo = {};
                TriggerScaleOut(UIContainer, transDesc, 0, 0.0f, 0.67f, 0.1f, 0.9f, 0.2f, 1.0f, 0.92f, 0.92f, 0.5f, 0.5f, false, false);
                ScheduleGadgetTransitions_DWMCheck(0, ARRAYSIZE(transDesc), transDesc, UIContainer->GetDisplayNode(), &tsbInfo);
                if (g_pctx->windowAnim && g_pctx->clientAnim)
                {
                    centered->SetVisible(false);
                    TriggerScaleIn(centered, transDesc, 0, 0.05f, 0.3f, 0.25f, 0.1f, 0.25f, 1.0f, 0.97f, 0.97f, 0.5f, 0.5f, 1.0f, 1.0f, 0.5f, 0.5f, true, false);
                    ScheduleGadgetTransitions_DWMCheck(0, ARRAYSIZE(transDesc), transDesc, nullptr, &tsbInfo);
                    AnimateWindow(hWnd, 10, AW_BLEND | AW_HIDE);
                    HANDLE AnimHandle = CreateThread(nullptr, 0, AnimateWindowWrapper2, nullptr, NULL, nullptr);
                    if (AnimHandle) CloseHandle(AnimHandle);
                    SetTimer(subviewwnd->GetHWND(), 2, 50, nullptr);
                }
            }
            break;
        }
        case WM_NCACTIVATE:
        {
            if (wParam == 0)
            {
                HWND hForeground = GetForegroundWindow();
                if (!hForeground)
                {
                    HWND hTrayNotify = FindWindowExW(g_hWndTaskbar, nullptr, L"TrayNotifyWnd", nullptr);
                    HWND hShowDesktop = FindWindowExW(hTrayNotify, nullptr, L"TrayShowDesktopButtonWClass", nullptr);
                    RECT rc;
                    POINT pt;
                    GetWindowRect(hShowDesktop, &rc);
                    GetCursorPos(&pt);
                    if (PtInRect(&rc, pt))
                    {
                        g_peek = false;
                        HidePopupCore(true, true);
                    }
                }
            }
            break;
        }
        case WM_TIMER:
        {
            KillTimer(hWnd, wParam);
            switch (wParam)
            {
            case 1:
                if (g_tempElem)
                    if (!((Element*)g_tempElem)->IsDestroyed())
                        if (((Element*)g_tempElem)->GetID() == StrToID(L"ResetDesktop"))
                            ((Element*)g_tempElem)->SetEnabled(true);
                break;
            case 2:
                fullscreenpopupbg->SetVisible(g_issubviewopen);
                break;
            }
            break;
        }
        case WM_USER + 1:
        {
            yValueEx* yV = (yValueEx*)lParam;
            vector<LVItem*>* l_pm = yV->vpm;
            for (int num = 0; num < yV->num; num++)
            {
                if (num >= l_pm->size()) break;
                if (!(*l_pm)[num])
                    continue;
                (*l_pm)[num]->SetVisible(true);
            }
            break;
        }
        case WM_USER + 2:
        {
            subviewwnd->ShowWindow(SW_HIDE);
            if (g_pendingaction) Sleep(700);
            if (lParam == 1)
            {
                HideSimpleView(false);
            }
            centered->DestroyAll(true);
            break;
        }
        case WM_USER + 3:
        {
            int innerSizeX = GetSystemMetricsForDpi(SM_CXICONSPACING, g_pctx->dpi) + (g_iconsz - 48) * g_pctx->flScaleFactor;
            int innerSizeY = GetSystemMetricsForDpi(SM_CYICONSPACING, g_pctx->dpi) + (g_iconsz - 48) * g_pctx->flScaleFactor - textm.tmHeight;
            int iconPaddingX = (GetSystemMetricsForDpi(SM_CXICONSPACING, g_pctx->dpi) - 48 * g_pctx->flScaleFactor) / 2;
            int iconPaddingY = (GetSystemMetricsForDpi(SM_CYICONSPACING, g_pctx->dpi) - 48 * g_pctx->flScaleFactor) / 2;
            yValueEx* yV = (yValueEx*)lParam;
            vector<LVItem*>* l_pm = yV->vpm;
            vector<DesktopIcon*>* vdi = (vector<DesktopIcon*>*)wParam;
            LVItem* lvi{}, *lvi2{};
            if (yV->peOptionalTarget1)
                lvi = (LVItem*)yV->peOptionalTarget1->GetParent()->GetParent()->GetParent();
            if (yV->peOptionalTarget2)
                lvi2 = *((LVItem**)yV->peOptionalTarget2);
            if (!yV->peOptionalTarget1)
            {
                lvi = lvi2;
                if (!yV->peOptionalTarget2)
                {
                    delete yV;
                    break;
                }
            }
            for (int num = 0; num < yV->num; num++)
            {
                if (num >= l_pm->size()) break;
                if (!(*l_pm)[num])
                    continue;
                DWORD lviFlags = (*l_pm)[num]->GetFlags();
                DDScalableElement* peIcon = (*l_pm)[num]->GetIcon();
                Element* peShortcutArrow = (*l_pm)[num]->GetShortcutArrow();
                RichText* peText = (*l_pm)[num]->GetText();
                if (!g_touchmode)
                {
                    (*l_pm)[num]->SetWidth(innerSizeX);
                    (*l_pm)[num]->SetHeight(innerSizeY + textm.tmHeight + 23 * g_pctx->flScaleFactor);
                    int textlines = 1;
                    if (textm.tmHeight <= 18 * g_pctx->flScaleFactor) textlines = 2;
                    if (peText)
                    {
                        peText->SetHeight(textm.tmHeight * textlines + 4 * g_pctx->flScaleFactor);
                    }
                    if (peIcon)
                    {
                        short shadedSize{}, shadedX{}, shadedY{};
                        if (!(lviFlags & LVIF_HIDDEN || g_isGlass))
                        {
                            shadedSize = 16;
                            shadedX = 8 * g_pctx->flScaleFactor;
                            shadedY = 6 * g_pctx->flScaleFactor;
                        }
                        peIcon->SetWidth((g_iconsz + shadedSize) * g_pctx->flScaleFactor);
                        peIcon->SetHeight((g_iconsz + shadedSize) * g_pctx->flScaleFactor);
                        peIcon->SetX(iconPaddingX - shadedX);
                        peIcon->SetY((iconPaddingY * 0.575) - shadedY);
                        if ((*l_pm)[num]->GetFlags() & LVIF_HIDDEN)
                        {
                            peIcon->SetAlpha(128);
                            peText->SetAlpha(128);
                        }
                    }
                }
                if ((*vdi)[num])
                {
                    HBITMAP iconbmp = (*vdi)[num]->icon;
                    CValuePtr spvBitmap = DirectUI::Value::CreateGraphic(iconbmp, 2, 0xffffffff, false, false, false);
                    if (iconbmp) DeleteObject(iconbmp);
                    if (spvBitmap && peIcon) peIcon->SetValue(Element::ContentProp, 1, spvBitmap);
                    HBITMAP iconshortcutbmp = (*vdi)[num]->iconshortcut;
                    CValuePtr spvBitmapShortcut = DirectUI::Value::CreateGraphic(iconshortcutbmp, 2, 0xffffffff, false, false, false);
                    if (iconshortcutbmp) DeleteObject(iconshortcutbmp);
                    if (spvBitmapShortcut && peShortcutArrow && lviFlags & LVIF_SHORTCUT) peShortcutArrow->SetValue(Element::ContentProp, 1, spvBitmapShortcut);
                    HBITMAP textbmp = (*vdi)[num]->text;
                    CValuePtr spvBitmapText = DirectUI::Value::CreateGraphic(textbmp, 2, 0xffffffff, false, false, false);
                    if (textbmp) DeleteObject(textbmp);
                    if (spvBitmapText && peText) peText->SetValue(Element::ContentProp, 1, spvBitmapText);
                }
                if (g_touchmode)
                {
                    if ((*vdi)[num])
                    {
                        BYTE intensity = (lviFlags & LVIF_HIDDEN) ? g_isGlass ? 16 : 192 : g_isGlass ? 64 : 255;
                        (*l_pm)[num]->SetDDCPIntensity(intensity);
                        (*l_pm)[num]->SetAssociatedColor((*vdi)[num]->crDominantTile);
                        COLORREF glowcolor = CreateGlowColor((*vdi)[num]->crDominantTile);
                        (*l_pm)[num]->GetInnerElement()->SetAssociatedColor(glowcolor);
                        if (g_showfolderitemcount && (*l_pm)[num]->GetFlags() & LVIF_DIR)
                        {
                            DDScalableRichText* peItemCount = (*l_pm)[num]->GetItemCountElement();
                            peItemCount->SetAssociatedColor(0xFF000000 | glowcolor);
                            if (GetRValue(glowcolor) * 0.299 + GetGValue(glowcolor) * 0.587 + GetBValue(glowcolor) * 0.114 > 152)
                                peItemCount->SetForegroundColor(0xFF000000);
                            else peItemCount->SetForegroundColor(0xFFFFFFFF);
                        }
                    }
                    if (lviFlags & LVIF_HIDDEN || g_isGlass)
                    {
                        short iconspace = 8 * g_pctx->flScaleFactor;
                        peIcon->SetPadding(iconspace, iconspace, iconspace, iconspace);
                    }
                }
                else if (g_showfolderitemcount && l_pm && (*l_pm)[num]->GetFlags() & LVIF_DIR)
                    SendMessageW(hWnd, WM_USER + 6, (WPARAM)((*l_pm)[num]), (LPARAM)lvi);
            }
            if (yV->peOptionalTarget1)
            {
                CSafeElementPtr<TouchScrollViewer> groupdirlist;
                groupdirlist.Assign((TouchScrollViewer*)regElem(L"groupdirlist", lvi));
                CSafeElementPtr<Element> dirtitle;
                dirtitle.Assign(regElem(L"dirtitle", lvi));
                if (groupdirlist)
                {
                    groupdirlist->SetVisible(true);
                    dirtitle->SetVisible(true);
                }

                DWORD dwFlags = NULL;
                if (lvi->GetClassInfoW() == LVItem::GetClassInfoPtr())
                    dwFlags = lvi->GetFlags();

                if (!(dwFlags & LVIF_NOGROUPANIM) && groupdirlist)
                {
                    RECT rcList;
                    groupdirlist->GetVisibleRect(&rcList);
                    GTRANS_DESC transDesc[3];
                    TriggerTranslate(groupdirlist, transDesc, 0, 0.2f, 0.7f, 0.1f, 0.9f, 0.2f, 1.0f, 0.0f, 100.0f * g_pctx->flScaleFactor, 0.0f, 0.0f, false, false, false);
                    TriggerFade(groupdirlist, transDesc, 1, 0.2f, 0.4f, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f, false, false, false);
                    TriggerClip(groupdirlist, transDesc, 2, 0.2f, 0.7f, 0.1f, 0.9f, 0.2f, 1.0f, 0.0f, 0.0f, 1.0f, (rcList.bottom - rcList.top - 100 * g_pctx->flScaleFactor) / (rcList.bottom - rcList.top), 0.0f, 0.0f, 1.0f, 1.0f, false, false);
                    TransitionStoryboardInfo tsbInfo = {};
                    ScheduleGadgetTransitions_DWMCheck(0, ARRAYSIZE(transDesc), transDesc, groupdirlist->GetDisplayNode(), &tsbInfo);

                    TriggerFade(dirtitle, transDesc, 0, 0.0f, 0.2f, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f, false, false, false);
                    ScheduleGadgetTransitions_DWMCheck(0, ARRAYSIZE(transDesc) - 2, transDesc, dirtitle->GetDisplayNode(), &tsbInfo);
                }

                CSafeElementPtr<Element> emptyview;
                emptyview.Assign(regElem(L"emptyview", lvi));
                if (emptyview)
                {
                    emptyview->DestroyAll(true);
                    emptyview->Destroy(true);
                }

                yV->peOptionalTarget1->DestroyAll(true);
                yV->peOptionalTarget1->Destroy(true);
            }
            if (lvi->GetRoot() != subviewparent)
            {
                if (lvi2->GetFlags() & LVIF_GROUP && g_treatdirasgroup)
                {
                    if (yV->peOptionalTarget1)
                        lvi->SetOpenDirState(LVIODS_PINNED);
                    if (lvi2->GetIcon()->GetGroupColor() != 0)
                        lvi2->GetIcon()->SetAssociatedColor(lvi2->GetAssociatedColor());
                }
            }
            lvi->RemoveFlags(LVIF_NOGROUPANIM);
            for (int i = 0; i < vdi->size(); i++)
            {
                free((*vdi)[i]);
            }
            delete yV;
            break;
        }
        case WM_USER + 4:
        {
            int innerSizeX = GetSystemMetricsForDpi(SM_CXICONSPACING, g_pctx->dpi) + (g_iconsz - 48) * g_pctx->flScaleFactor;
            int innerSizeY = GetSystemMetricsForDpi(SM_CYICONSPACING, g_pctx->dpi) + (g_iconsz - 48) * g_pctx->flScaleFactor - textm.tmHeight;
            int iconPaddingX = (GetSystemMetricsForDpi(SM_CXICONSPACING, g_pctx->dpi) - 48 * g_pctx->flScaleFactor) / 2;
            int iconPaddingY = (GetSystemMetricsForDpi(SM_CYICONSPACING, g_pctx->dpi) - 48 * g_pctx->flScaleFactor) / 2;
            yValueEx* yV = (yValueEx*)lParam;
            vector<LVItem*>* l_pm = yV->vpm;
            for (int num = 0; num < yV->num; num++)
            {
                if (num >= l_pm->size()) break;
                if ((*l_pm)[num])
                {
                    Element* peShortcutArrow = (*l_pm)[num]->GetShortcutArrow();
                    Element* peItemCount = (*l_pm)[num]->GetItemCountElement();
                    if (g_touchmode)
                    {
                        if (g_showfolderitemcount && (*l_pm)[num]->GetFlags() & LVIF_DIR)
                        {
                            peItemCount->SetVisible(true);
                            WCHAR itemCount[32], temp[32];
                            LoadStrFromRes(temp, 32, 4032);
                            if ((*l_pm)[num]->GetItemCount() == 1) LoadStrFromRes(itemCount, 32, 4031);
                            else StringCchPrintfW(itemCount, 64, temp, (*l_pm)[num]->GetItemCount());
                            if ((*l_pm)[num]->GetTileSize() == LVITS_ICONONLY)
                                peItemCount->SetContentString(to_wstring((*l_pm)[num]->GetItemCount()).c_str());
                            else
                                peItemCount->SetContentString(itemCount);
                        }
                    }
                    else
                    {
                        peShortcutArrow->SetWidth(g_shiconsz * g_pctx->flScaleFactor);
                        peShortcutArrow->SetHeight(g_shiconsz * g_pctx->flScaleFactor);
                        peShortcutArrow->SetX(iconPaddingX);
                        peShortcutArrow->SetY((iconPaddingY * 0.575) + (g_iconsz - g_shiconsz) * g_pctx->flScaleFactor);
                        if (g_showfolderitemcount && (*l_pm)[num]->GetFlags() & LVIF_DIR)
                        {
                            peItemCount->SetVisible(true);
                            RECT rcItemCount;
                            peItemCount->SetContentString(to_wstring((*l_pm)[num]->GetItemCount()).c_str());
                            GetGadgetRect(peItemCount->GetDisplayNode(), &rcItemCount, 0);
                            peItemCount->SetX(g_iconsz * g_pctx->flScaleFactor + iconPaddingX - rcItemCount.right + rcItemCount.left);
                            peItemCount->SetY((iconPaddingY * 0.575) + g_iconsz * g_pctx->flScaleFactor - rcItemCount.bottom + rcItemCount.top);
                        }
                    }
                }
            }
            break;
        }
        case WM_USER + 5:
        {
            g_pendingaction = true;
            Element* peTemp = reinterpret_cast<Element*>(wParam);
            peTemp->SetEnabled(!peTemp->GetEnabled());
            if (lParam == 1 && ((DDScalableTouchButton*)peTemp)->GetAssociatedFn() != nullptr)
            {
                ((DDScalableTouchButton*)peTemp)->ExecAssociatedFn(((DDScalableTouchButton*)peTemp)->GetAssociatedFn());
                g_pendingaction = false;
            }
            break;
        }
        case WM_USER + 6:
        {
            LVItem* lviChild = (LVItem*)wParam;
            Element* lvi = (Element*)lParam;
            if (lvi && !(lviChild->IsDestroyed()))
            {
                DDScalableRichText* peItemCount = lviChild->GetItemCountElement();
                if (g_isGlass)
                {
                    peItemCount->SetDDCPIntensity(g_pctx->theme ? 96 : 160);
                    peItemCount->SetAssociatedColor(g_pctx->theme ? 65793 : 16711422);
                }
                else
                {
                    BYTE groupcolor{};
                    if (lvi->GetClassInfoW() == LVItem::GetClassInfoPtr())
                        groupcolor = ((LVItem*)lvi)->GetIcon()->GetGroupColor();
                    else
                    {
                        // any task button will do the job
                        CSafeElementPtr<DDLVActionButton> lvbutton;
                        lvbutton.Assign((DDLVActionButton*)regElem(L"OpenInExplorer", lvi));
                        groupcolor = lvbutton->GetAssociatedItem()->GetIcon()->GetGroupColor();
                    }
                    if (!g_touchmode)
                        peItemCount->SetAssociatedColor(0xFF000000 | ((groupcolor == 0) ? g_isColorized ? (iconColorID == 0) ? g_pctx->theme ?
                            RGB(64, 64, 64) : RGB(224, 224, 224) : g_colorPickerPalette[iconColorID] : g_colorPickerPalette[1] : g_colorPickerPalette[groupcolor]));
                }
            }
            break;
        }
        }
        return CallWindowProc(WndProcSubview, hWnd, uMsg, wParam, lParam);
    }

    LRESULT CALLBACK InnerWindowProc2(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
    {
        return CallWindowProc(WndProcSubviewInner, hWnd, uMsg, wParam, lParam);
    }

    HANDLE g_subiconSemaphore = CreateSemaphoreW(nullptr, 16, 16, nullptr);

    DWORD WINAPI subfastin_icons(LPVOID lpParam)
    {
        yValueEx* yV = (yValueEx*)lpParam;
        vector<LVItem*>* l_pm = yV->vpm;
        int num = yV->fl1;
        bool initCom = (*l_pm)[num]->GetFlags() & LVIF_ADVANCEDICON;
        if (initCom)
            CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);
        COLORREF crSubdir = (COLORREF)yV->num;
        DesktopIcon* di = (DesktopIcon*)yV->peOptionalTarget1;
        ApplyIcons(l_pm, di, true, num, 1, crSubdir);
        if (initCom)
            CoUninitialize();
        return 0;
    }

    DWORD WINAPI SubviewIconsHelper(LPVOID lpParam)
    {
        InitThread(TSM_DESKTOP_DYNAMIC);
        WaitForSingleObject(g_subiconSemaphore, 0);
        yValueEx* yV = static_cast<yValueEx*>(lpParam);
        subfastin_icons(yV);
        delete yV;
        ReleaseSemaphore(g_subiconSemaphore, 1, nullptr);
        UnInitThread();
        return 0;
    }

    DWORD WINAPI subfastin(LPVOID lpParam)
    {
        InitThread(TSM_DESKTOP_DYNAMIC);
        Sleep(25);
        yValueEx* yV = (yValueEx*)lpParam;
        vector<LVItem*>* l_pm = yV->vpm;
        vector<DesktopIcon*> vdi;
        LVItem** pplvi = (LVItem**)yV->peOptionalTarget2;
        if (!pplvi)
        {
            UnInitThread();
            delete yV;
            return 0;
        }
        COLORREF colorPickerPalette[8] =
        {
            (iconColorID == 1) ? ImmersiveColor : IconColorizationColor, ImmersiveColor,
            RGB(0, 120, 215), RGB(177, 70, 194), RGB(232, 17, 35),
            RGB(247, 99, 12), RGB(255, 185, 0), RGB(0, 204, 106)
        };
        int count2{};
        if (yV->peOptionalTarget1 && *pplvi) // only re-enumerate when there's a pending container (optional target 1)
            EnumerateFolder((LPWSTR)RemoveQuotes((*pplvi)->GetFilename()).c_str(), l_pm, &count2, yV->num);
        if (*pplvi && !((*pplvi)->GetFlags() & LVIF_GROUPEX))
        {
            UnInitThread();
            delete yV;
            return 0;
        }
        for (int num = 0; num < yV->num; num++)
        {
            if (!(*l_pm)[num])
                continue;
            if (yV->peOptionalTarget1)
                (*l_pm)[num]->AddFlags(LVIF_REFRESH);
        }
        for (int num = 0; num < yV->num; num++)
        {
            if (*pplvi && !((*pplvi)->GetFlags() & LVIF_GROUPEX))
            {
                for (int num2 = 0; num2 < num - 1; num2++)
                {
                    DeleteObject(vdi[num2]->icon);
                    DeleteObject(vdi[num2]->iconshortcut);
                    DeleteObject(vdi[num2]->text);
                    free(vdi[num2]);
                }
                vdi.clear();
                UnInitThread();
                delete yV;
                return 0;
            }
            if (!(*l_pm)[num])
            {
                vdi.push_back(nullptr);
                continue;
            }
            if ((*l_pm)[num]->GetFlags() & LVIF_REFRESH)
            {
                DesktopIcon* di = new DesktopIcon;
                vdi.push_back(di);
                if (!((*l_pm)[num]->GetFlags() & LVIF_TEXTONLY))
                {
                    CSafeElementPtr<DDScalableElement> IconElement;
                    if (pplvi && *pplvi)
                        IconElement.Assign((DDScalableElement*)regElem(L"iconElem", *pplvi));
                    yValueEx* yV3 = new yValueEx{ static_cast<int>(colorPickerPalette[IconElement->GetGroupColor()]),
                        static_cast<float>(num), NULL, l_pm, reinterpret_cast<Element*>(di), nullptr };
                    QueueUserWorkItem(SubviewIconsHelper, yV3, 0);
                    WaitForSingleObject(g_subiconSemaphore, 1000);
                }
            }
            else
                vdi.push_back(nullptr);
        }
        if (yV->num < 64)
            Sleep(128 - yV->num * 2); // give some time for smaller folders to load their icons
        bool refreshable = true;
        for (int num = 0; num < yV->num; num++)
        {
            if (*pplvi && !((*pplvi)->GetFlags() & LVIF_GROUPEX))
            {
                for (int num2 = 0; num2 < num - 1; num2++)
                {
                    DeleteObject(vdi[num2]->icon);
                    DeleteObject(vdi[num2]->iconshortcut);
                    DeleteObject(vdi[num2]->text);
                    free(vdi[num2]);
                }
                vdi.clear();
                UnInitThread();
                delete yV;
                return 0;
            }
            if (!(*l_pm)[num])
                continue;
            if ((*l_pm)[num]->GetFlags() & LVIF_REFRESH)
            {
                DesktopIcon* di = vdi[num];
                if (di)
                {
                    int lines_basedOnEllipsis{};
                    DWORD alignment{};
                    RECT g_touchmoderect{};
                    int innerSizeX = GetSystemMetricsForDpi(SM_CXICONSPACING, g_pctx->dpi) + (g_iconsz - 48) * g_pctx->flScaleFactor;
                    int textlines = 1;
                    if (textm.tmHeight <= 18 * g_pctx->flScaleFactor) textlines = 2;
                    yValue* yV2 = new yValue{ num, yV->fl1, yV->fl2 };
                    if (g_touchmode) CalcDesktopIconInfo(yV2, &lines_basedOnEllipsis, &alignment, true, yV->vpm);
                    HBITMAP capturedBitmap{};
                    if (!(*l_pm)[num])
                    {
                        delete yV2;
                        continue;
                    }
                    if (g_touchmode) CreateTextBitmap(capturedBitmap, (*l_pm)[num]->GetSimpleFilename().c_str(), yV2->fl1 - 4 * g_pctx->flScaleFactor, lines_basedOnEllipsis, alignment, g_touchmode, NULL);
                    else CreateTextBitmap(capturedBitmap, (*l_pm)[num]->GetSimpleFilename().c_str(), innerSizeX, textm.tmHeight * textlines, DT_CENTER | DT_END_ELLIPSIS, g_touchmode, NULL);
                    delete yV2;
                    if (g_touchmode)
                    {
                        if (g_isGlass)
                            di->crDominantTile = RGB(224, 224, 224);
                        if (GetRValue(di->crDominantTile) * 0.299 + GetGValue(di->crDominantTile) * 0.587 + GetBValue(di->crDominantTile) * 0.114 > 152)
                        {
                            IterateBitmap(capturedBitmap, DesaturateWhiten, 1, 0, 1, NULL);
                            IterateBitmap(capturedBitmap, SimpleBitmapPixelHandler, 1, 0, 1, NULL);
                        }
                        else IterateBitmap(capturedBitmap, DesaturateWhiten, 1, 0, 1.33, NULL);
                    }
                    else if (g_pctx->theme && !g_touchmode)
                    {
                        IterateBitmap(capturedBitmap, DesaturateWhiten, 1, 0, 1, NULL);
                        IterateBitmap(capturedBitmap, SimpleBitmapPixelHandler, 1, 0, 0.9, NULL);
                    }
                    else IterateBitmap(capturedBitmap, DesaturateWhiten, 1, 0, 1.33, NULL);
                    if (capturedBitmap != nullptr) di->text = capturedBitmap;
                }
                if (!(*l_pm)[num])
                    continue;
                (*l_pm)[num]->RemoveFlags(LVIF_REFRESH);
                (*l_pm)[num]->RemoveFlags(LVIF_TEXTONLY);
            }
            else if (g_showfolderitemcount && (*l_pm)[num]->GetFlags() & LVIF_DIR)
            {
                refreshable = false;
                Element* lvi{};
                if (yV->peOptionalTarget1)
                    lvi = yV->peOptionalTarget1->GetParent()->GetParent()->GetParent();
                else if (*pplvi)
                    lvi = *pplvi;
                SendMessageW(subviewwnd->GetHWND(), WM_USER + 6, (WPARAM)((*l_pm)[num]), (LPARAM)lvi);
            }
        }
        if (refreshable)
        {
            SendMessageW(subviewwnd->GetHWND(), WM_USER + 1, NULL, (LPARAM)yV);
            SendMessageW(subviewwnd->GetHWND(), WM_USER + 4, NULL, (LPARAM)yV);
            SendMessageW(subviewwnd->GetHWND(), WM_USER + 3, (WPARAM)&vdi, (LPARAM)yV);
        }
        UnInitThread();
        return 0;
    }

    DWORD WINAPI animate6(LPVOID lpParam)
    {
        DWORD animCoef = g_pctx->animCoef;
        if (g_pctx->AnimShiftKey && !(GetAsyncKeyState(VK_SHIFT) & 0x8000)) animCoef = 100;
        if (!g_pctx->windowAnim || !g_pctx->clientAnim) animCoef = 0;
        Sleep(175 * (animCoef / 100.0f));
        if (g_pctx->windowAnim && g_pctx->clientAnim)
            AnimateWindow(subviewwnd->GetHWND(), 120 * (animCoef / 100.0f), AW_BLEND | AW_HIDE);
        else
            subviewwnd->ShowWindow(SW_HIDE);
        //CloakWindow(subviewwnd->GetHWND(), true);
        BlurBackground(subviewwnd->GetHWND(), false, true, 0x33, fullscreenpopupbg);
        SetTimer(subviewwnd->GetHWND(), 2, 0, nullptr);
        SendMessageW(subviewwnd->GetHWND(), WM_USER + 2, NULL, NULL);
        SetForegroundWindow(wnd->GetHWND());
        return 0;
    }

    DWORD WINAPI AnimateWindowWrapper2(LPVOID lpParam)
    {
        DWORD animCoef = g_pctx->animCoef;
        if (g_pctx->AnimShiftKey && !(GetAsyncKeyState(VK_SHIFT) & 0x8000)) animCoef = 100;
        if (g_pctx->windowAnim && g_pctx->clientAnim)
            AnimateWindow(subviewwnd->GetHWND(), 150 * (animCoef / 100.0f), AW_BLEND);
        else
            subviewwnd->ShowWindow(SW_SHOW);
        return 0;
    }

    HRESULT CloakWindow(HWND hwnd, bool fCloak)
    {
        HRESULT hr = S_OK;

        if (hwnd)
        {
            BOOL fCloak2 = fCloak;
            hr = DwmSetWindowAttribute(hwnd, DWMWA_CLOAK, &fCloak2, sizeof(fCloak2));
            if (SUCCEEDED(hr))
            {
                if (IsCompositionActive())
                {
                    ShowWindow(hwnd, SW_SHOWNA);
                }
                else
                {
                    ShowWindow(hwnd, fCloak ? SW_HIDE : SW_SHOWNA);
                }
            }
        }

        return hr;
    }

    void fullscreenAnimation(int width, int height, float animstartscale, float desktopanimstartscale, POINT peIconOrigin, Element** ppeAnimateFrom)
    {
        CValuePtr v;
        RECT dimensions;
        GetClientRect(subviewwnd->GetHWND(), &dimensions);
        RECT dimensionsAnim;
        GetClientRect(wnd->GetHWND(), &dimensionsAnim);
        RECT padding = *(popupcontainer->GetPadding(&v));
        int maxwidth = dimensions.right - padding.left - padding.right;
        int maxheight = dimensions.bottom - padding.top - padding.bottom;
        if (width > maxwidth) width = maxwidth;
        if (height > maxheight) height = maxheight;
        float flOriginX = 0.5f, flOriginY = 0.5f;
        float flX3D = 0.0f, flY3D = 0.0f;
        float flOriginX3D = 0.5f, flOriginY3D = 0.5f;
        float flFadeStart = 0.15f;
        float flFadeDuration = 0.233f;
        float flScaleStart = 0.15f;
        float flScaleDuration = 0.4f;
        float flrX0 = 0.0f;
        float flrY0 = 0.0f;
        float flrX1 = 0.0f;
        float flrY1 = 1.0f;
        float animstartscaleX = animstartscale;
        float animstartscaleY = animstartscale;
        TransitionStoryboardInfo tsbInfo = {};
        bool hasOrigin = peIconOrigin.x > -1 && peIconOrigin.y > -1;
        if (hasOrigin)
        {
            Element* peAnimateFrom = *ppeAnimateFrom;
            animstartscaleX = peAnimateFrom->GetWidth() / static_cast<float>(width);
            animstartscaleY = peAnimateFrom->GetHeight() / static_cast<float>(height);
            flOriginX += (peIconOrigin.x - dimensionsAnim.right / 2.0f) / (width - peAnimateFrom->GetWidth());
            flOriginY += (peIconOrigin.y - dimensionsAnim.bottom / 2.0f) / (height - peAnimateFrom->GetHeight());
            float flOriginX2 = 0.5f + (flOriginX - 0.5f) * desktopanimstartscale;
            float flOriginY2 = 0.5f + (flOriginY - 0.5f) * desktopanimstartscale;
            flX3D = 45.0f * (peIconOrigin.y - dimensionsAnim.bottom / 2.0f) / dimensionsAnim.bottom;
            flY3D = -45.0f * (peIconOrigin.x - dimensionsAnim.right / 2.0f) / dimensionsAnim.right;
            flOriginX3D = 1.0f - peIconOrigin.x / static_cast<float>(dimensionsAnim.right);
            flOriginY3D = 1.0f - peIconOrigin.y / static_cast<float>(dimensionsAnim.bottom);
            if (flX3D == 0.0f && flY3D == 0.0f)
                hasOrigin = false;
            flFadeStart = 0.05f;
            flFadeDuration = 0.3f;
            flScaleStart = 0.0f;
            flScaleDuration = 0.5f;
            flrX0 = 0.8f;
            flrY0 = 0.0f;
            flrX1 = 0.0f;
            flrY1 = 1.0f;
            GTRANS_DESC transDesc_peAnimate[3];
            TriggerFade_Ref(ppeAnimateFrom, transDesc_peAnimate, 0, flFadeStart, flFadeDuration, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f, 0.0f, true, false, true);
            TriggerScaleIn(peAnimateFrom, transDesc_peAnimate, 1, flScaleStart, flScaleDuration, flrX0, flrY0, flrX1, flrY1, 1.0f, 1.0f,
                flOriginX2, flOriginY2, 1 / animstartscaleX / desktopanimstartscale, 1 / animstartscaleY / desktopanimstartscale, flOriginX2, flOriginY2, false, false);
            if (hasOrigin) TriggerRotate3D(peAnimateFrom, transDesc_peAnimate, 2, flScaleStart, flScaleDuration - flFadeDuration, 1.0f, 0.0f, 1.0f, 1.0f, 0.0f, 0.0f, 0.0f, flX3D, flY3D, 0.0f, flOriginX3D, flOriginY3D, 1.0f, false, false);
            ScheduleGadgetTransitions_DWMCheck(0, hasOrigin ? 3 : 2, transDesc_peAnimate, peAnimateFrom->GetDisplayNode(), &tsbInfo);
        }
        parserSubview->CreateElement(L"fullscreeninner", nullptr, nullptr, nullptr, (Element**)&fullscreeninner);
        centered->Add((Element**)&fullscreeninner, 1);
        if (g_pctx->DWMActive)
        {
            AddLayeredRef(fullscreeninner->GetDisplayNode());
            SetGadgetFlags(fullscreeninner->GetDisplayNode(), NULL, NULL);
        }
        centered->SetWidth(width);
        centered->SetHeight(height);
        fullscreeninner->SetWidth(width);
        fullscreeninner->SetHeight(height);
        centered->SetBackgroundColor(0);
        fullscreenpopupbase->SetVisible(true);
        GTRANS_DESC transDesc[3];
        TriggerFade(fullscreeninner, transDesc, 0, flFadeStart, flFadeDuration, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f, true, false, true);
        TriggerScaleIn(fullscreeninner, transDesc, 1, flScaleStart, flScaleDuration, flrX0, flrY0, flrX1, flrY1,
            animstartscaleX, animstartscaleY, flOriginX, flOriginY, 1.0f, 1.0f, flOriginX, flOriginY, false, false);
        if (hasOrigin) TriggerRotate3D(fullscreeninner, transDesc, 2, flScaleStart, flScaleDuration, 0.8f, 0.0f, 0.0f, 1.0f, flX3D, flY3D, 0.0f, 0.0f, 0.0f, 0.0f, flOriginX3D, flOriginY3D, 0.0f, false, false);
        ScheduleGadgetTransitions_DWMCheck(0, hasOrigin ? 3 : 2, transDesc, fullscreeninner->GetDisplayNode(), &tsbInfo);
        GTRANS_DESC transDesc2[1];
        TriggerScaleOut(UIContainer, transDesc2, 0, 0.0f, 0.67f, 0.1f, 0.9f, 0.2f, 1.0f, desktopanimstartscale, desktopanimstartscale, 0.5f, 0.5f, false, false);
        ScheduleGadgetTransitions_DWMCheck(0, ARRAYSIZE(transDesc2), transDesc2, UIContainer->GetDisplayNode(), &tsbInfo);
        SetTimer(wnd->GetHWND(), 7, 100, nullptr);
        g_issubviewopen = true;
        DWORD dwMillis = (g_pctx->windowAnim && g_pctx->clientAnim) ? 50 : 0;
        SetTimer(subviewwnd->GetHWND(), 2, dwMillis, nullptr);
    }

    void fullscreenAnimation2(Element** ppeAnimateTo)
    {
        if (g_issubviewopen)
        {
            RECT dimensionsAnim;
            GetClientRect(wnd->GetHWND(), &dimensionsAnim);
            float flOriginX = 0.5f, flOriginY = 0.5f;
            float flX3D = 0.0f, flY3D = 0.0f;
            float flOriginX3D = 0.5f, flOriginY3D = 0.5f;
            float flFadeStart = 0.0f;
            float flScaleDuration = 0.175f;
            float flrX0 = 1.0f;
            float flrY0 = 1.0f;
            float flrX1 = 0.0f;
            float flrY1 = 1.0f;
            float animstartscaleX = 0.95f;
            float animstartscaleY = 0.95f;
            GTRANS_DESC transDesc[3];
            TransitionStoryboardInfo tsbInfo = {};
            bool hasOrigin = false;
            if (ppeAnimateTo && *ppeAnimateTo && fullscreeninner)
            {
                Element* peAnimateTo = *ppeAnimateTo;
                hasOrigin = true;
                POINT ptZero{}, peIconOrigin{};
                UIContainer->MapElementPoint(peAnimateTo, &ptZero, &peIconOrigin);
                RECT rcIcon{}, rcFakeWindow{};
                GetGadgetRect(peAnimateTo->GetDisplayNode(), &rcIcon, 0x8);
                peIconOrigin.x += (rcIcon.right - rcIcon.left) / 2;
                peIconOrigin.y += (rcIcon.bottom - rcIcon.top) / 2;
                GetGadgetRect(fullscreeninner->GetDisplayNode(), &rcFakeWindow, 0x8);
                flOriginX += (peIconOrigin.x - dimensionsAnim.right / 2.0f) / (rcFakeWindow.right - peAnimateTo->GetWidth());
                flOriginY += (peIconOrigin.y - dimensionsAnim.bottom / 2.0f) / (rcFakeWindow.bottom - peAnimateTo->GetHeight());
                flX3D = 45.0f * (peIconOrigin.y - dimensionsAnim.bottom / 2.0f) / dimensionsAnim.bottom;
                flY3D = -45.0f * (peIconOrigin.x - dimensionsAnim.right / 2.0f) / dimensionsAnim.right;
                flOriginX3D = 1.0f - peIconOrigin.x / static_cast<float>(dimensionsAnim.right);
                flOriginY3D = 1.0f - peIconOrigin.y / static_cast<float>(dimensionsAnim.bottom);
                if (flX3D == 0.0f && flY3D == 0.0f)
                    hasOrigin = false;
                animstartscaleX = peAnimateTo->GetWidth() / static_cast<float>(rcFakeWindow.right);
                animstartscaleY = peAnimateTo->GetHeight() / static_cast<float>(rcFakeWindow.bottom);
                flFadeStart = 0.1f;
                flScaleDuration = 0.4f;
                flrX0 = 0.8f;
                flrY0 = 0.0f;
                flrX1 = 0.0f;
                flrY1 = 1.0f;
                bool hide = true;
                if (peAnimateTo->GetClassInfoW() == LVItem::GetClassInfoPtr())
                    if (g_touchmode && ((LVItem*)peAnimateTo)->GetGroupSize() != LVIGS_NORMAL)
                        hide = false;
                TriggerFade_Ref(ppeAnimateTo, transDesc, 0, 0.1f, 0.15f, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f, hide, false, false);
                TriggerScaleIn(peAnimateTo, transDesc, 1, 0.0f, 0.4f, flrX0, flrY0, flrX1, flrY1, 1 / animstartscaleX, 1 / animstartscaleY,
                    flOriginX, flOriginY, 1.0f, 1.0f, flOriginX, flOriginY, false, false);
                TriggerRotate3D(peAnimateTo, transDesc, 2, 0.1f, 0.4f, 0.6f, 0.3f, 0.0f, 0.9f, flX3D, flY3D, 0.0f, 0.0f, 0.0f, 0.0f, flOriginX3D, flOriginY3D, 1.0f, false, false);
                ScheduleGadgetTransitions_DWMCheck(0, hasOrigin ? 3 : 2, transDesc, peAnimateTo->GetDisplayNode(), &tsbInfo);
                DUI_SetGadgetZOrder(peAnimateTo, -1);
            }
            if (fullscreeninner)
            {
                TriggerScaleOut(fullscreeninner, transDesc, 0, 0.0f, flScaleDuration, flrX0, flrY0, flrX1, flrY1, animstartscaleX, animstartscaleY, flOriginX, flOriginY, false, false);
                TriggerFade(fullscreeninner, transDesc, 1, flFadeStart, 0.15f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f, 0.0f, true, false, true);
                if (hasOrigin) TriggerRotate3D(fullscreeninner, transDesc, 2, 0.0f, 0.33f, 0.8f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, flX3D, flY3D, 0.0f, flOriginX3D, flOriginY3D, 1.0f, false, false);
                ScheduleGadgetTransitions_DWMCheck(0, hasOrigin ? 3 : 2, transDesc, fullscreeninner->GetDisplayNode(), &tsbInfo);
            }
            GTRANS_DESC transDesc2[1];
            TriggerScaleOut(UIContainer, transDesc2, 0, 0.175f, 0.675f, 0.1f, 0.9f, 0.2f, 1.0f, 1.0f, 1.0f, 0.5f, 0.5f, false, false);
            ScheduleGadgetTransitions_DWMCheck(0, ARRAYSIZE(transDesc2), transDesc2, UIContainer->GetDisplayNode(), &tsbInfo);
            DUI_SetGadgetZOrder(UIContainer, -1);
        }
        DWORD animThread;
        HANDLE animThreadHandle = CreateThread(nullptr, 0, animate6, nullptr, 0, &animThread);
        if (animThreadHandle) CloseHandle(animThreadHandle);
    }

    void ShowPopupCore(Element** ppeAnimateFrom)
    {
        if (g_issubviewopen) HidePopupCore(true, false);
        POINT ptZero{}, ptIcon{};
        if (!ppeAnimateFrom || !(*ppeAnimateFrom)) ptIcon.x = -1, ptIcon.y = -1;
        else
        {
            UIContainer->MapElementPoint(*ppeAnimateFrom, &ptZero, &ptIcon);
            RECT rcIcon{};
            GetGadgetRect((*ppeAnimateFrom)->GetDisplayNode(), &rcIcon, 0x8);
            ptIcon.x += (rcIcon.right - rcIcon.left) / 2;
            ptIcon.y += (rcIcon.bottom - rcIcon.top) / 2;
        }
        fullscreenAnimation(800 * g_pctx->flScaleFactor, 480 * g_pctx->flScaleFactor, 0.8, 0.92, ptIcon, ppeAnimateFrom);
        HANDLE AnimHandle = CreateThread(nullptr, 0, AnimateWindowWrapper2, nullptr, NULL, nullptr);
        if (AnimHandle) CloseHandle(AnimHandle);
        BlurBackground(subviewwnd->GetHWND(), true, true, 0x33, fullscreenpopupbg);
        SendMessageW(subviewwnd->GetHWND(), WM_CHANGEUISTATE, 3, NULL);
    }

    void HidePopupCore(bool WinDInvoked, bool fNoRefresh)
    {
        if (!WinDInvoked) SendMessageW(g_hWndTaskbar, WM_COMMAND, 416, 0);
        Element** ppeAnimateTo{};
        for (int i = 0; i < pm.size(); i++)
        {
            if (!(g_treatdirasgroup && pm[i]->GetGroupSize() != LVIGS_NORMAL))
                pm[i]->RemoveFlags(LVIF_GROUPEX);
            if (pm[i]->GetOpenDirState() == LVIODS_FULLSCREEN)
            {
                if (g_touchmode) ppeAnimateTo = (Element**)&pm[i];
                else ppeAnimateTo = (Element**)pm[i]->GetIconRef();
                if (pm[i]->GetGroupSize() == LVIGS_NORMAL && g_isColorized)
                {
                    IconThumbHelper(i);
                    yValue* yV = new yValue{ i };
                    HANDLE smThumbnailThreadHandle = CreateThread(nullptr, 0, CreateIndividualThumbnail, (LPVOID)yV, 0, nullptr);
                    if (smThumbnailThreadHandle) CloseHandle(smThumbnailThreadHandle);
                    if (g_touchmode)
                    {
                        pm[i]->AddFlags(LVIF_REFRESH);
                        yValue* yV = new yValue{ i };
                        QueueUserWorkItem(RearrangeIconsHelper, yV, 0);
                    }
                }
                vector<LVItem*>* children = pm[i]->GetChildItems();
                if (children)
                {
                    for (int i = 0; i < children->size(); i++)
                        (*children)[i] = nullptr;
                }
            }
            if (!(g_treatdirasgroup && pm[i]->GetGroupSize() != LVIGS_NORMAL))
                pm[i]->SetOpenDirState(LVIODS_NONE);
        }
        if (g_issettingsopen && g_pctx->atleastonesetting)
        {
            WCHAR pszTitle[64];
            LoadStrFromRes(pszTitle, 64, 4042);
            DDNotificationBanner* ddnb = new DDNotificationBanner();
            ddnb->CreateBanner(DDNT_SUCCESS, pszTitle, nullptr, 3);
        }
        //SetWindowPos(subviewwnd->GetHWND(), HWND_BOTTOM, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
        
        // 0.5.8: We need to gracefully process the Animation2 or DestroyAll,
        // most importantly when the user exits the subview before a folder's icons are loaded.
        // It would involve waiting until we get a signal that the folder is ready.
        // While this is a rare occurrence and the icon loading CAN terminate itself if the user exist too early,
        // it would still be a good improvement for stability.
        if (fNoRefresh) fullscreenAnimation2(ppeAnimateTo);
        else
            centered->DestroyAll(true);
        g_issubviewopen = false;
        g_issettingsopen = false;
        g_pctx->atleastonesetting = false;
    }

    void SelectSubItem(Element* elem, Event* iev)
    {
        if (iev->uidType == LVItem::Click)
        {
            wstring temp = RemoveQuotes(((LVItem*)elem)->GetFilename());
            LaunchItem(temp.c_str());
        }
    }

    void SelectSubItemListener(Element* elem, const PropertyInfo* pProp, int type, Value* pV1, Value* pV2)
    {
        if (g_touchmode)
        {
            GTRANS_DESC transDesc[1];
            TransitionStoryboardInfo tsbInfo = {};
            float coef{};
            if (pProp == TouchButton::PressedProp())
            {
                ((LVItem*)elem)->GetInnerElement()->SetEnabled(!((LVItem*)elem)->GetPressed());
                coef = ((LVItem*)elem)->GetPressed() ? 0.9325f : 1.0f;
                goto TLVITEMANIMATION;
            }
            if (pProp == TouchButton::MouseWithinProp())
            {
                coef = ((LVItem*)elem)->GetMouseWithin() ? 1.0625f : 1.0f;
            TLVITEMANIMATION:
                TriggerScaleOut(elem, transDesc, 0, 0.0f, 0.25f, 0.25f, 0.1f, 0.25f, 1.0f, coef, coef, 0.5f, 0.5f, false, false);
                ScheduleGadgetTransitions_DWMCheck(0, ARRAYSIZE(transDesc), transDesc, nullptr, &tsbInfo);
                DUI_SetGadgetZOrder(elem, -1);
            }
        }
    }

    void ShowDirAsGroup(LVItem** pplvi)
    {
        if (!pplvi) return;
        LVItem* lvi = *pplvi;
        if (!lvi) return;
        unsigned short lviCount = lvi->GetItemCount();
        Element** ppeAnimate = (Element**)lvi->GetIconRef();
        if (g_touchmode) ppeAnimate = (Element**)pplvi;
        SendMessageW(g_hWndTaskbar, WM_COMMAND, 419, 0);
        ShowPopupCore(ppeAnimate);
        SetWindowPos(subviewwnd->GetHWND(), HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
        lvi->AddFlags(LVIF_GROUPEX);
        lvi->SetOpenDirState(LVIODS_FULLSCREEN);
        Element* groupdirectory{};
        parserSubview->CreateElement(L"groupdirectory", nullptr, nullptr, nullptr, (Element**)&groupdirectory);
        CSafeElementPtr<DDScalableTouchButton> fullscreeninner; fullscreeninner.Assign((DDScalableTouchButton*)regElem(L"fullscreeninner", centered));
        fullscreeninner->Add((Element**)&groupdirectory, 1);
        CSafeElementPtr<DDScalableElement> iconElement;
        iconElement.Assign((DDScalableElement*)regElem(L"iconElem", lvi));
        fullscreeninner->SetDDCPIntensity(iconElement->GetDDCPIntensity());
        fullscreeninner->SetAssociatedColor(iconElement->GetAssociatedColor());
        CSafeElementPtr<TouchScrollViewer> groupdirlist;
        groupdirlist.Assign((TouchScrollViewer*)regElem(L"groupdirlist", groupdirectory));
        CSafeElementPtr<DDScalableElement> lvi_SubUIContainer;
        lvi_SubUIContainer.Assign((DDScalableElement*)regElem(L"SubUIContainer", groupdirlist));
        if (lviCount > 0)
        {
            vector<IElementListener*> v_pels;
            vector<LVItem*>* subpm = new vector<LVItem*>;
            StyleSheet* sheet = pSubview->GetSheet();
            CValuePtr sheetStorage = DirectUI::Value::CreateStyleSheet(sheet);
            parser->GetSheet(g_pctx->theme ? L"default" : L"defaultdark", &sheetStorage);
            const WCHAR* elemname = g_touchmode ? L"outerElemTouch" : L"outerElem";
            for (int i = 0; i < lviCount; i++)
            {
                LVItem* outerElemGrouped;
                parser->CreateElement(elemname, nullptr, nullptr, nullptr, (Element**)&outerElemGrouped);
                outerElemGrouped->SetValue(Element::SheetProp, 1, sheetStorage);
                outerElemGrouped->SetInnerElement((DDScalableElement*)regElem(L"innerElem", outerElemGrouped));
                outerElemGrouped->SetIcon((DDScalableElement*)regElem(L"iconElem", outerElemGrouped));
                outerElemGrouped->SetShortcutArrow(regElem(L"shortcutElem", outerElemGrouped));
                outerElemGrouped->SetText((RichText*)regElem(L"textElem", outerElemGrouped));
                outerElemGrouped->SetItemCountElement((DDScalableRichText*)regElem(L"folderItemsElem", outerElemGrouped));
                subpm->push_back(outerElemGrouped);
            }
            CSafeElementPtr<LVItem> PendingContainer;
            PendingContainer.Assign((LVItem*)regElem(L"PendingContainer", groupdirectory));
            PendingContainer->SetVisible(true);
            int x = 0, y = 0;
            int maxX{}, xRuns{};
            CValuePtr v;
            RECT dimensions;
            dimensions = *(groupdirectory->GetPadding(&v));
            int outerSizeX = GetSystemMetricsForDpi(SM_CXICONSPACING, g_pctx->dpi) + (g_iconsz - 44) * g_pctx->flScaleFactor;
            int outerSizeY = GetSystemMetricsForDpi(SM_CYICONSPACING, g_pctx->dpi) + (g_iconsz - 21) * g_pctx->flScaleFactor;
            if (g_touchmode)
            {
                outerSizeX = g_touchSizeX + DESKPADDING_TOUCH * g_pctx->flScaleFactor;
                outerSizeY = g_touchSizeY + DESKPADDING_TOUCH * g_pctx->flScaleFactor;
            }
            for (int j = 0; j < lviCount; j++)
            {
                v_pels.push_back(assignFn((*subpm)[j], SelectSubItem, true));
                v_pels.push_back(assignFn((*subpm)[j], ItemRightClick, true));
                v_pels.push_back(assignExtendedFn((*subpm)[j], SelectSubItemListener, true));
                v_pels.push_back(assignExtendedFn((*subpm)[j], LVCommon::RefineSelections, true));
                (*subpm)[j]->SetListeners(v_pels);
                v_pels.clear();
                if (!g_touchmode) (*subpm)[j]->SetClass(L"singleclicked");
                int xRender = (localeType == 1) ? (centered->GetWidth() - (dimensions.left + dimensions.right + outerSizeX)) - x : x;
                (*subpm)[j]->SetX(xRender), (*subpm)[j]->SetY(y);
                x += outerSizeX;
                xRuns++;
                if (x > centered->GetWidth() - (dimensions.left + dimensions.right + outerSizeX))
                {
                    maxX = xRuns;
                    xRuns = 0;
                    x = 0;
                    y += outerSizeY;
                }
            }
            x -= outerSizeX;
            if (maxX != 0 && xRuns % maxX != 0) y += outerSizeY;
            lvi_SubUIContainer->SetHeight(y);
            CSafeElementPtr<Element> dirtitle;
            dirtitle.Assign(regElem(L"dirtitle", groupdirectory));
            RECT rcList;
            groupdirlist->GetVisibleRect(&rcList);
            for (int j = 0; j < lviCount; j++)
            {
                if (localeType == 1 && y > rcList.bottom - rcList.top)
                    (*subpm)[j]->SetX((*subpm)[j]->GetX() - GetSystemMetricsForDpi(SM_CXVSCROLL, g_pctx->dpi));
            }
            lvi_SubUIContainer->Add((Element**)&(*subpm)[0], lviCount);
            lvi->SetChildItems(subpm);
            DWORD animThread2;
            yValueEx* yV = new yValueEx{ lviCount, NULL, NULL, subpm, PendingContainer, (Element*)pplvi };
            HANDLE animThreadHandle2 = CreateThread(nullptr, 0, subfastin, (LPVOID)yV, 0, &animThread2);
            if (animThreadHandle2) CloseHandle(animThreadHandle2);
        }
        else
        {
            CSafeElementPtr<Element> emptyview;
            emptyview.Assign(regElem(L"emptyview", groupdirectory));
            emptyview->SetVisible(true);
            CSafeElementPtr<DDScalableElement> emptygraphic;
            emptygraphic.Assign((DDScalableElement*)regElem(L"emptygraphic", groupdirectory));
            if (iconElement->GetGroupColor() >= 1)
                emptygraphic->SetAssociatedColor(g_colorPickerPalette[iconElement->GetGroupColor()]);
            CSafeElementPtr<Element> dirtitle;
            dirtitle.Assign(regElem(L"dirtitle", groupdirectory));
            dirtitle->SetVisible(true);
        }
        CSafeElementPtr<DDScalableElement> dirname;
        dirname.Assign((DDScalableElement*)regElem(L"dirname", groupdirectory));
        dirname->SetContentString(lvi->GetSimpleFilename().c_str());
        CSafeElementPtr<DDScalableElement> dirdetails;
        dirdetails.Assign((DDScalableElement*)regElem(L"dirdetails", groupdirectory));
        WCHAR itemCount[32], temp[32];
        LoadStrFromRes(temp, 32, 4032);
        if (lviCount == 1) LoadStrFromRes(itemCount, 32, 4031);
        else StringCchPrintfW(itemCount, 32, temp, lviCount);
        dirdetails->SetContentString(itemCount);
        if (lviCount == 0) dirdetails->SetContentString(L"");
        CSafeElementPtr<Element> tasks;
        tasks.Assign(regElem(L"tasks", groupdirectory));
        CSafeElementPtr<DDLVActionButton> Group_Back;
        Group_Back.Assign((DDLVActionButton*)regElem(L"Group_Back", groupdirectory));
        CSafeElementPtr<DDLVActionButton> Pin;
        Pin.Assign((DDLVActionButton*)regElem(L"Pin", groupdirectory));
        CSafeElementPtr<DDLVActionButton> Customize;
        Customize.Assign((DDLVActionButton*)regElem(L"Customize", groupdirectory));
        CSafeElementPtr<DDLVActionButton> OpenInExplorer;
        OpenInExplorer.Assign((DDLVActionButton*)regElem(L"OpenInExplorer", groupdirectory));
        Pin->SetVisible(true), Customize->SetVisible(true), OpenInExplorer->SetVisible(true);
        Pin->SetEnabled(isDefaultRes());
        assignFn(Group_Back, CloseCustomizePage);
        assignFn(OpenInExplorer, OpenGroupInExplorer);
        assignFn(Customize, OpenCustomizePage);
        assignFn(Pin, PinGroup);
        OpenInExplorer->SetAssociatedItem(lvi);
        Customize->SetAssociatedItem(lvi);
        Pin->SetAssociatedItem(lvi);
    }

    void DisableColorPicker(Element* elem, Event* iev)
    {
        if (iev->uidType == DDToggleButton::Click)
        {
            CSafeElementPtr<DDColorPicker> DDCP_Icons;
            DDCP_Icons.Assign((DDColorPicker*)regElem(L"DDCP_Icons", (Element*)g_tempElem));
            DDCP_Icons->SetEnabled(((DDToggleButton*)elem)->GetCheckedState());
        }
    }

    void DisableDarkToggle(Element* elem, Event* iev)
    {
        if (iev->uidType == DDToggleButton::Click)
        {
            CSafeElementPtr<DDToggleButton> EnableDarkIcons;
            EnableDarkIcons.Assign((DDToggleButton*)regElem(L"EnableDarkIcons", (Element*)g_tempElem));
            if (((DDCheckBox*)elem)->GetCheckedState() == true)
            {
                EnableDarkIcons->SetCheckedState(!g_pctx->theme);
                g_isDarkIconsEnabled = !g_pctx->theme;
                SetRegistryValues(HKEY_CURRENT_USER, L"Software\\DirectDesktop\\Personalize", L"DarkIcons", !g_pctx->theme, false, nullptr);
            }
            EnableDarkIcons->SetEnabled(!((DDCheckBox*)elem)->GetCheckedState());
        }
    }

    void SetViewHelper(Element* elem, Event* iev)
    {
        if (iev->uidType == TouchButton::Click)
        {
            CSafeElementPtr<DDSlider> IconSize;
            IconSize.Assign((DDSlider*)regElem(L"IconSize", elem->GetRoot()));
            int iconsize = IconSize->GetCurrentValue();
            int shortcutsize{}, smallsize{};
            shortcutsize = 32;
            if (iconsize > 96) shortcutsize = 64;
            else if (iconsize > 48) shortcutsize = 48;
            smallsize = 12;
            if (iconsize > 120) smallsize = 48;
            else if (iconsize >= 80) smallsize = 32;
            else if (iconsize > 40) smallsize = 16;
            SetView(iconsize, shortcutsize, smallsize, false);
        }
    }

    void OpenDeskCpl(Element* elem, Event* iev)
    {
        if (iev->uidType == TouchButton::Click) ShellExecuteW(nullptr, L"open", L"control.exe", L"desk.cpl,Web,0", nullptr, SW_SHOW);
    }

    void OpenLog(Element* elem, Event* iev)
    {
        if (iev->uidType == TouchButton::Click)
        {
            wchar_t* desktoplog = new wchar_t[260];
            wchar_t* cBuffer = new wchar_t[260];
            DWORD d = GetEnvironmentVariableW(L"userprofile", cBuffer, 260);
            StringCchPrintfW(desktoplog, 260, L"%s\\Documents\\DirectDesktop.log", cBuffer);
            ShellExecuteW(nullptr, L"open", L"notepad.exe", desktoplog, nullptr, SW_SHOW);
            delete[] desktoplog;
            delete[] cBuffer;
        }
    }

    void SetDefaultRes(Element* elem, Event* iev)
    {
        if (iev->uidType == Button::Click || iev->uidType == TouchButton::Click)
        {
            RECT dimensions;
            SystemParametersInfoW(SPI_GETWORKAREA, sizeof(dimensions), &dimensions, NULL);
            g_defWidth = dimensions.right / g_pctx->flScaleFactor;
            SetRegistryValues(HKEY_CURRENT_USER, L"Software\\DirectDesktop", L"DefaultWidth", g_defWidth, false, nullptr);
            g_defHeight = dimensions.bottom / g_pctx->flScaleFactor;
            SetRegistryValues(HKEY_CURRENT_USER, L"Software\\DirectDesktop", L"DefaultHeight", g_defHeight, false, nullptr);
            if (g_issettingsopen)
            {
                if (elem->GetID() == StrToID(L"SetDefaultRes")) elem->SetEnabled(false);
                CSafeElementPtr<DDScalableElement> CustomResDesc;
                CustomResDesc.Assign((DDScalableElement*)regElem(L"CustomResDesc", elem->GetRoot()));
                WCHAR desc[256];
                StringCchPrintfW(desc, 256, L"Current default desktop area is %d x %d, likely %d x %d with %d dpi", g_defWidth, g_defHeight,
                    static_cast<int>(ceil(g_defWidth * g_pctx->flScaleFactor)), static_cast<int>(ceil(g_defHeight * g_pctx->flScaleFactor)), g_pctx->dpi);
                if (CustomResDesc) CustomResDesc->SetContentString(desc);
            }
        }
    }

    void ResetDesktopSize(Element* elem, Event* iev)
    {
        if (iev->uidType == TouchButton::Click)
        {
            WCHAR DesktopLayoutWithSize[24];
            if (!g_touchmode) StringCchPrintfW(DesktopLayoutWithSize, 24, L"DesktopLayout_%d", g_iconsz);
            else StringCchPrintfW(DesktopLayoutWithSize, 24, L"DesktopLayout_Touch");
            if (EnsureRegValueExists(HKEY_CURRENT_USER, L"Software\\DirectDesktop", DesktopLayoutWithSize))
            {
                RegDeleteKeyValueW(HKEY_CURRENT_USER, L"Software\\DirectDesktop", DesktopLayoutWithSize);
                if (EnsureRegValueExists(HKEY_CURRENT_USER, L"Software\\DirectDesktop", L"GroupSizeTable"))
                    RegDeleteKeyValueW(HKEY_CURRENT_USER, L"Software\\DirectDesktop", L"GroupSizeTable");
                InitLayout(true, false, false);
                g_tempElem = elem;
                elem->SetEnabled(false);
                SetTimer(subviewwnd->GetHWND(), 1, 2000, nullptr);
                WCHAR clearMsg[64];
                if (!g_touchmode)
                {
                    WCHAR msgBuf[64];
                    LoadStrFromRes(msgBuf, 64, 4094);
                    StringCchPrintfW(clearMsg, 64, msgBuf, g_iconsz);
                }
                else LoadStrFromRes(clearMsg, 64, 4095);
                DDNotificationBanner* ddnb = new DDNotificationBanner();
                ddnb->CreateBanner(DDNT_SUCCESS, nullptr, clearMsg, 3);
            }
        }
    }

    void ModifyShellState(bool unused1, bool unused2, bool unused3)
    {
        shellstate[4] ^= 0x20;
        SetRegistryBinValues(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer", L"ShellState", shellstate, _msize(shellstate), false, nullptr);
        CSafeElementPtr<DDCheckBox> UnderlineMode;
        UnderlineMode.Assign((DDCheckBox*)regElem(L"UnderlineMode", fullscreeninner));
        UnderlineMode->SetEnabled(!(shellstate[4] & 0x20));
        SHChangeNotify(SHCNE_ALLEVENTS, SHCNF_IDLIST, nullptr, nullptr);
        SendMessageTimeoutW(HWND_BROADCAST, WM_SETTINGCHANGE, 0, (LPARAM)L"ShellState", SMTO_NORMAL, 200, nullptr);
    }

    void UpdateIconColorizationColorAux(bool unused1, bool unused2, bool unused3)
    {
        UpdateIconColorizationColor(RegistryListener, DDScalableElement::AssociatedColorProp(), 0, nullptr, nullptr);
    }

    void ToggleEffectSelection(bool unused1, bool unused2, bool unused3)
    {
        CSafeElementPtr<DDCheckBox> LaunchEffects;
        LaunchEffects.Assign((DDCheckBox*)regElem(L"LaunchEffects", fullscreeninner));
        CSafeElementPtr<DDCombobox> LaunchEffectsSelection;
        LaunchEffectsSelection.Assign((DDCombobox*)regElem(L"LaunchEffectsSelection", fullscreeninner));
        LaunchEffectsSelection->SetEnabled(LaunchEffects->GetCheckedState());
    }

    void ShowPage1(Element* pePage)
    {
        if (pePage)
        {
            CSafeElementPtr<DDToggleButton> ItemCheckboxes;
            ItemCheckboxes.Assign((DDToggleButton*)regElem(L"ItemCheckboxes", pePage));
            CSafeElementPtr<DDToggleButton> ShowHiddenFiles;
            ShowHiddenFiles.Assign((DDToggleButton*)regElem(L"ShowHiddenFiles", pePage));
            CSafeElementPtr<DDToggleButton> FilenameExts;
            FilenameExts.Assign((DDToggleButton*)regElem(L"FilenameExts", pePage));
            CSafeElementPtr<DDToggleButton> TreatDirAsGroup;
            TreatDirAsGroup.Assign((DDToggleButton*)regElem(L"TreatDirAsGroup", pePage));
            CSafeElementPtr<DDCheckBox> ShowFolderItemCount;
            ShowFolderItemCount.Assign((DDCheckBox*)regElem(L"ShowFolderItemCount", pePage));
            CSafeElementPtr<DDScalableElement> ClickModeLabel;
            ClickModeLabel.Assign((DDScalableElement*)regElem(L"ClickModeLabel", pePage));
            CSafeElementPtr<DDCombobox> ClickMode;
            ClickMode.Assign((DDCombobox*)regElem(L"ClickMode", pePage));
            CSafeElementPtr<DDCheckBox> UnderlineMode;
            UnderlineMode.Assign((DDCheckBox*)regElem(L"UnderlineMode", pePage));
            CSafeElementPtr<DDToggleButton> TripleClickAndHide;
            TripleClickAndHide.Assign((DDToggleButton*)regElem(L"TripleClickAndHide", pePage));
            CSafeElementPtr<DDToggleButton> LockIconPos;
            LockIconPos.Assign((DDToggleButton*)regElem(L"LockIconPos", pePage));
            RegKeyValue rkvTemp{};
            rkvTemp.SetHKeyName(HKEY_CURRENT_USER);
            rkvTemp.SetPath(L"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced");
            rkvTemp.SetValueToFind(L"AutoCheckSelect");
            ItemCheckboxes->SetCheckedState(g_pctx->showcheckboxes);
            ItemCheckboxes->SetRegKeyValue(rkvTemp);
            ItemCheckboxes->SetShellInteraction(true);
            rkvTemp.SetValueToFind(L"Hidden");
            if (GetRegistryValues(rkvTemp.GetHKeyName(), rkvTemp.GetPath(), rkvTemp.GetValueToFind()) == 1) ShowHiddenFiles->SetCheckedState(true);
            else ShowHiddenFiles->SetCheckedState(false);
            ShowHiddenFiles->SetRegKeyValue(rkvTemp);
            ShowHiddenFiles->SetShellInteraction(true);
            rkvTemp.SetValueToFind(L"HideFileExt");
            FilenameExts->SetCheckedState(GetRegistryValues(rkvTemp.GetHKeyName(), rkvTemp.GetPath(), rkvTemp.GetValueToFind()));
            FilenameExts->SetRegKeyValue(rkvTemp);
            FilenameExts->SetShellInteraction(true);
            rkvTemp.SetPath(L"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer");
            rkvTemp.SetValueToFind(L"ShellState");
            WCHAR pszBuf[256];
            GetDialogString(pszBuf, 256, 29959, L"shell32.dll", 65535, 2);
            ClickModeLabel->SetContentString(pszBuf);
            GetDialogString(pszBuf, 256, 29959, L"shell32.dll", 30102, NULL);
            ClickMode->InsertSelection(DDCombobox::MAX_SELECTIONS, pszBuf);
            GetDialogString(pszBuf, 256, 29959, L"shell32.dll", 30103, NULL);
            ClickMode->InsertSelection(DDCombobox::MAX_SELECTIONS, pszBuf);
            ClickMode->SetSelection(shellstate[4] & 0x20 ? 1 : 0);
            ClickMode->SetAssociatedFn(ModifyShellState, false, false, false);
            rkvTemp.SetValueToFind(L"IconUnderline");
            GetDialogString(pszBuf, 256, 29959, L"shell32.dll", 30105, NULL);
            UnderlineMode->SetContentString(pszBuf);
            UnderlineMode->SetEnabled(!(shellstate[4] & 0x20));
            UnderlineMode->SetCheckedState(3 - GetRegistryValues(rkvTemp.GetHKeyName(), rkvTemp.GetPath(), rkvTemp.GetValueToFind()));
            UnderlineMode->SetRegKeyValue(rkvTemp);
            UnderlineMode->SetShellInteraction(true);
            rkvTemp.SetPath(L"Software\\DirectDesktop");
            rkvTemp.SetValueToFind(L"TreatDirAsGroup");
            TreatDirAsGroup->SetCheckedState(g_treatdirasgroup);
            TreatDirAsGroup->SetAssociatedSetting(&g_treatdirasgroup);
            TreatDirAsGroup->SetAssociatedFn(InitLayout, false, false, true);
            TreatDirAsGroup->SetRegKeyValue(rkvTemp);
            rkvTemp.SetValueToFind(L"FolderItemCount");
            ShowFolderItemCount->SetCheckedState(g_showfolderitemcount);
            ShowFolderItemCount->SetAssociatedSetting(&g_showfolderitemcount);
            ShowFolderItemCount->SetAssociatedFn(InitLayout, false, false, true);
            ShowFolderItemCount->SetRegKeyValue(rkvTemp);
            rkvTemp.SetValueToFind(L"TripleClickAndHide");
            TripleClickAndHide->SetCheckedState(g_tripleclickandhide);
            TripleClickAndHide->SetAssociatedSetting(&g_tripleclickandhide);
            TripleClickAndHide->SetRegKeyValue(rkvTemp);
            rkvTemp.SetValueToFind(L"LockIconPos");
            LockIconPos->SetCheckedState(g_lockiconpos);
            LockIconPos->SetAssociatedSetting(&g_lockiconpos);
            LockIconPos->SetRegKeyValue(rkvTemp);
            assignFn(ItemCheckboxes, ToggleSetting);
            assignFn(ShowHiddenFiles, ToggleSetting);
            assignFn(FilenameExts, ToggleSetting);
            assignFn(ClickMode, ToggleSetting);
            assignFn(UnderlineMode, ToggleSetting);
            assignFn(TreatDirAsGroup, ToggleSetting);
            assignFn(ShowFolderItemCount, ToggleSetting);
            assignFn(TripleClickAndHide, ToggleSetting);
            assignFn(LockIconPos, ToggleSetting);
        }
    }

    void ShowPage2(Element* pePage)
    {
        if (pePage)
        {
            CSafeElementPtr<DDToggleButton> EnableAccent;
            EnableAccent.Assign((DDToggleButton*)regElem(L"EnableAccent", pePage));
            CSafeElementPtr<DDColorPicker> DDCP_Icons;
            DDCP_Icons.Assign((DDColorPicker*)regElem(L"DDCP_Icons", pePage));
            CSafeElementPtr<DDToggleButton> EnableDarkIcons;
            EnableDarkIcons.Assign((DDToggleButton*)regElem(L"EnableDarkIcons", pePage));
            CSafeElementPtr<DDCheckBox> AutoDarkIcons;
            AutoDarkIcons.Assign((DDCheckBox*)regElem(L"AutoDarkIcons", pePage));
            CSafeElementPtr<DDSlider> IconSize;
            IconSize.Assign((DDSlider*)regElem(L"IconSize", pePage));
            CSafeElementPtr<DDScalableTouchButton> ApplyIconSize;
            ApplyIconSize.Assign((DDScalableTouchButton*)regElem(L"ApplyIconSize", pePage));
            CSafeElementPtr<DDToggleButton> IconThumbnails;
            IconThumbnails.Assign((DDToggleButton*)regElem(L"IconThumbnails", pePage));
            CSafeElementPtr<DDScalableTouchButton> DesktopIconSettings;
            DesktopIconSettings.Assign((DDScalableTouchButton*)regElem(L"DesktopIconSettings", pePage));
            RegKeyValue rkvTemp{};
            rkvTemp.SetHKeyName(HKEY_CURRENT_USER);
            rkvTemp.SetPath(L"Software\\DirectDesktop\\Personalize");
            rkvTemp.SetValueToFind(L"AccentColorIcons");
            EnableAccent->SetCheckedState(g_isColorized);
            EnableAccent->SetAssociatedSetting(&g_isColorized);
            EnableAccent->SetAssociatedFn(RearrangeIcons, false, true, true);
            EnableAccent->SetRegKeyValue(rkvTemp);
            rkvTemp.SetValueToFind(L"IconColorID");
            DDCP_Icons->SetThemeAwareness(false);
            DDCP_Icons->SetEnabled(g_isColorized);
            DDCP_Icons->SetRegKeyValue(rkvTemp);
            vector<DDScalableElement*> elemTargets{};
            elemTargets.push_back(RegistryListener);
            DDCP_Icons->SetTargetElements(elemTargets);
            elemTargets.clear();
            rkvTemp.SetValueToFind(L"DarkIcons");
            EnableDarkIcons->SetEnabled(!g_automaticDark);
            EnableDarkIcons->SetCheckedState(g_isDarkIconsEnabled);
            EnableDarkIcons->SetAssociatedSetting(&g_isDarkIconsEnabled);
            EnableDarkIcons->SetAssociatedFn(UpdateIconColorizationColorAux, false, false, false);
            EnableDarkIcons->SetRegKeyValue(rkvTemp);
            rkvTemp.SetValueToFind(L"AutoDarkIcons");
            AutoDarkIcons->SetCheckedState(g_automaticDark);
            AutoDarkIcons->SetAssociatedSetting(&g_automaticDark);
            AutoDarkIcons->SetAssociatedFn(RearrangeIcons, false, true, true);
            AutoDarkIcons->SetRegKeyValue(rkvTemp);
            IconSize->SetMinValue(32);
            IconSize->SetMaxValue(144);
            IconSize->SetCurrentValue(g_iconsz, false);
            IconSize->SetTickValue(8);
            IconSize->SetFormattedString(L"%.0f");
            IconSize->SetEnabled(!g_touchmode);
            ApplyIconSize->SetEnabled(!g_touchmode);
            rkvTemp.SetPath(L"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced");
            rkvTemp.SetValueToFind(L"IconsOnly");
            IconThumbnails->SetCheckedState(GetRegistryValues(rkvTemp.GetHKeyName(), rkvTemp.GetPath(), rkvTemp.GetValueToFind()));
            IconThumbnails->SetRegKeyValue(rkvTemp);
            IconThumbnails->SetShellInteraction(true);
            assignFn(EnableAccent, ToggleSetting);
            assignFn(EnableAccent, DisableColorPicker);
            assignFn(EnableDarkIcons, ToggleSetting);
            assignFn(AutoDarkIcons, ToggleSetting);
            assignFn(AutoDarkIcons, DisableDarkToggle);
            assignFn(ApplyIconSize, SetViewHelper);
            assignFn(IconThumbnails, ToggleSetting);
            assignFn(DesktopIconSettings, OpenDeskCpl);
            g_tempElem = (void*)pePage;
        }
    }

    void AddAnItem(Element* elem, Event* iev)
    {
        if (iev->uidType == TouchButton::Click)
        {
            CSafeElementPtr<LVTiles> lvc1;
            lvc1.Assign((LVTiles*)regElem(L"lvc1", elem->GetRoot()));
            CSafeElementPtr<DDScalableTouchEdit> lvcAmount;
            lvcAmount.Assign((DDScalableTouchEdit*)regElem(L"lvcAmount", elem->GetRoot()));
            CValuePtr v;
            UINT amount = 0;
            const WCHAR* content = lvcAmount->GetContentString(&v);
            if (content && ValidateStrDigits(content)) amount = _wtoi(content);
            if (amount > 0)
            {
                LVItem** lvcT = new LVItem * [amount];
                for (int i = 0; i < amount; i++)
                    parserSubview->CreateElement(L"lvcItem", nullptr, nullptr, nullptr, (Element**)&lvcT[i]);
                lvc1->Add((Element**)lvcT, amount);
                delete[] lvcT;
            }
        }
    }

    void InsertSecond(Element* elem, Event* iev)
    {
        if (iev->uidType == TouchButton::Click)
        {
            CSafeElementPtr<LVTiles> lvc1;
            lvc1.Assign((LVTiles*)regElem(L"lvc1", elem->GetRoot()));
            CSafeElementPtr<DDScalableTouchEdit> lvcAmount;
            lvcAmount.Assign((DDScalableTouchEdit*)regElem(L"lvcAmount", elem->GetRoot()));
            CValuePtr v;
            DynamicArray<Element*>* pel = lvc1->GetWhitespaceElement()->GetChildren(&v);
            v->Release();
            UINT amount = 0;
            const WCHAR* content = lvcAmount->GetContentString(&v);
            if (content && ValidateStrDigits(content)) amount = _wtoi(content);
            if (amount > 0 && pel && pel->GetSize() > 1)
            {
                LVItem** lvcT = new LVItem*[amount];
                for (int i = 0; i < amount; i++)
                    parserSubview->CreateElement(L"lvcItem", nullptr, nullptr, nullptr, (Element**)&lvcT[i]);
                lvc1->Insert((Element**)lvcT, amount, 2);
                delete[] lvcT;
            }
        }
    }

    void RemoveThird(Element* elem, Event* iev)
    {
        if (iev->uidType == TouchButton::Click)
        {
            CSafeElementPtr<LVTiles> lvc1;
            lvc1.Assign((LVTiles*)regElem(L"lvc1", elem->GetRoot()));
            CSafeElementPtr<DDScalableTouchEdit> lvcAmount;
            lvcAmount.Assign((DDScalableTouchEdit*)regElem(L"lvcAmount", elem->GetRoot()));
            CValuePtr v;
            DynamicArray<Element*>* pel = lvc1->GetWhitespaceElement()->GetChildren(&v);
            v->Release();
            UINT amount = 0;
            const WCHAR* content = lvcAmount->GetContentString(&v);
            if (content && ValidateStrDigits(content)) amount = _wtoi(content);
            if (amount > 0 && pel && pel->GetSize() >= amount + 3)
            {
                LVItem** lvcT = new LVItem*[amount];
                for (int i = 0; i < amount; i++)
                    lvcT[i] = (LVItem*)pel->GetItem(i + 3);
                lvc1->RemoveAndDestroy((Element**)lvcT, amount);
                delete[] lvcT;
            }
        }
    }

    void ShowPage3(Element* pePage)
    {
        if (pePage)
        {
            CSafeElementPtr<DDToggleButton> EnableLogging;
            EnableLogging.Assign((DDToggleButton*)regElem(L"EnableLogging", pePage));
            CSafeElementPtr<DDScalableTouchButton> ViewLastLog;
            ViewLastLog.Assign((DDScalableTouchButton*)regElem(L"ViewLastLog", pePage));
            CSafeElementPtr<DDSlider> AnimSpeed;
            AnimSpeed.Assign((DDSlider*)regElem(L"AnimSpeed", pePage));
            CSafeElementPtr<DDCheckBox> AnimShiftKey;
            AnimShiftKey.Assign((DDCheckBox*)regElem(L"AnimShiftKey", pePage));
            CSafeElementPtr<DDToggleButton> ShowDbgInfo;
            ShowDbgInfo.Assign((DDToggleButton*)regElem(L"ShowDbgInfo", pePage));
            CSafeElementPtr<DDToggleButton> EnableExit;
            EnableExit.Assign((DDToggleButton*)regElem(L"EnableExit", pePage));
            CSafeElementPtr<DDCheckBox> LaunchEffects;
            LaunchEffects.Assign((DDCheckBox*)regElem(L"LaunchEffects", pePage));
            CSafeElementPtr<DDCombobox> LaunchEffectsSelection;
            LaunchEffectsSelection.Assign((DDCombobox*)regElem(L"LaunchEffectsSelection", pePage));
            CSafeElementPtr<DDScalableElement> CustomResDesc;
            CustomResDesc.Assign((DDScalableElement*)regElem(L"CustomResDesc", pePage));
            CSafeElementPtr<DDScalableTouchButton> SetCurrent;
            SetCurrent.Assign((DDScalableTouchButton*)regElem(L"SetCurrent", pePage));
            CSafeElementPtr<DDScalableTouchButton> ResetDesktop;
            ResetDesktop.Assign((DDScalableTouchButton*)regElem(L"ResetDesktop", pePage));
            CSafeElementPtr<DDScalableTouchButton> addlast;
            addlast.Assign((DDScalableTouchButton*)regElem(L"addlast", pePage));
            CSafeElementPtr<DDScalableTouchButton> inserttwo;
            inserttwo.Assign((DDScalableTouchButton*)regElem(L"inserttwo", pePage));
            CSafeElementPtr<DDScalableTouchButton> removethree;
            removethree.Assign((DDScalableTouchButton*)regElem(L"removethree", pePage));
            RegKeyValue rkvTemp{};
            rkvTemp.SetHKeyName(HKEY_CURRENT_USER);
            rkvTemp.SetPath(L"Software\\DirectDesktop\\Debug");
            rkvTemp.SetValueToFind(L"Logging");
            EnableLogging->SetCheckedState(7 - GetRegistryValues(rkvTemp.GetHKeyName(), rkvTemp.GetPath(), rkvTemp.GetValueToFind()));
            EnableLogging->SetRegKeyValue(rkvTemp);
            rkvTemp.SetValueToFind(L"AnimationSpeed");
            AnimSpeed->SetMinValue(0.5f);
            AnimSpeed->SetMaxValue(20.0f);
            AnimSpeed->SetCurrentValue(g_pctx->animCoef / 100.0f, false);
            //AnimSpeed->SetAssociatedValue((int*)&(g_pctx->animCoef), 100);
            AnimSpeed->SetTickValue(0.1f);
            AnimSpeed->SetFormattedString(L"%.1fx");
            AnimSpeed->SetRegKeyValue(rkvTemp);
            rkvTemp.SetValueToFind(L"AnimationsShiftKey");
            AnimShiftKey->SetCheckedState(g_pctx->AnimShiftKey);
            //AnimShiftKey->SetAssociatedSetting(&(g_pctx->AnimShiftKey));
            AnimShiftKey->SetRegKeyValue(rkvTemp);
            rkvTemp.SetValueToFind(L"ShowDebugInfo");
            ShowDbgInfo->SetCheckedState(g_debuginfo);
            ShowDbgInfo->SetAssociatedSetting(&g_debuginfo);
            ShowDbgInfo->SetAssociatedFn(ShowDebugInfoOnDesktop, false, false, false);
            ShowDbgInfo->SetRegKeyValue(rkvTemp);
            rkvTemp.SetValueToFind(L"EnableExiting");
            EnableExit->SetCheckedState(g_enableexit);
            EnableExit->SetAssociatedSetting(&g_enableexit);
            EnableExit->SetRegKeyValue(rkvTemp);
            rkvTemp.SetPath(L"Software\\DirectDesktop\\Personalize");
            rkvTemp.SetValueToFind(L"ItemLaunchEffectsEnabled");
            LaunchEffects->SetCheckedState(g_itemlauncheffectsenabled);
            LaunchEffects->SetAssociatedSetting(&g_itemlauncheffectsenabled);
            LaunchEffects->SetAssociatedFn(ToggleEffectSelection, false, false, false);
            LaunchEffects->SetRegKeyValue(rkvTemp);
            rkvTemp.SetValueToFind(L"ItemLaunchEffect");
            LaunchEffectsSelection->SetEnabled(g_itemlauncheffectsenabled);
            LaunchEffectsSelection->SetAssociatedSetting(&g_itemlauncheffect);
            LaunchEffectsSelection->InsertSelection(DDCombobox::MAX_SELECTIONS, L"Effect 1");
            LaunchEffectsSelection->SetSelection(GetRegistryValues(rkvTemp.GetHKeyName(), rkvTemp.GetPath(), rkvTemp.GetValueToFind()));
            LaunchEffectsSelection->SetRegKeyValue(rkvTemp);
            WCHAR desc[256], pszBuf[256];
            LoadStrFromRes(pszBuf, 256, 4083);
            StringCchPrintfW(desc, 256, pszBuf, g_defWidth, g_defHeight,
                static_cast<int>(ceil(g_defWidth * g_pctx->flScaleFactor)), static_cast<int>(ceil(g_defHeight * g_pctx->flScaleFactor)), g_pctx->dpi);
            CustomResDesc->SetContentString(desc);
            SetCurrent->SetEnabled(!isDefaultRes());
            assignFn(EnableLogging, ToggleSetting);
            assignFn(ViewLastLog, OpenLog);
            assignFn(AnimShiftKey, ToggleSetting);
            assignFn(ShowDbgInfo, ToggleSetting);
            assignFn(EnableExit, ToggleSetting);
            assignFn(LaunchEffects, ToggleSetting);
            assignFn(LaunchEffectsSelection, ToggleSetting);
            assignFn(SetCurrent, SetDefaultRes);
            assignFn(ResetDesktop, ResetDesktopSize);
            assignFn(addlast, AddAnItem);
            assignFn(inserttwo, InsertSecond);
            assignFn(removethree, RemoveThird);
        }
    }

    void ShowSettings(Element* elem, Event* iev)
    {
        if (iev->uidType == TouchButton::Click || iev->uidType == Button::Click)
        {
            HideSimpleView(false);
            g_editmode = false;
            ShowPopupCore(nullptr);
            SetFocus(subviewwnd->GetHWND());
            g_issettingsopen = true;
            Element* settingsview{};
            parserSubview->CreateElement(L"settingsview", nullptr, nullptr, nullptr, (Element**)&settingsview);
            CSafeElementPtr<DDScalableTouchButton> fullscreeninner; fullscreeninner.Assign((DDScalableTouchButton*)regElem(L"fullscreeninner", centered));
            fullscreeninner->Add((Element**)&settingsview, 1);
            CSafeElementPtr<DDTabbedPages> settingslist;
            settingslist.Assign((DDTabbedPages*)regElem(L"settingslist", settingsview));
            settingslist->BindParser(parserSubview);
            settingslist->SetMinSize(540 * g_pctx->flScaleFactor, 0);
            WCHAR pszBuf[64];
            LoadStrFromRes(pszBuf, 64, 4011);
            settingslist->InsertTab(0, L"SettingsPage1", pszBuf, ShowPage1);
            LoadStrFromRes(pszBuf, 64, 4012);
            settingslist->InsertTab(1, L"SettingsPage2", pszBuf, ShowPage2);
            if (g_debugmode)
            {
                LoadStrFromRes(pszBuf, 64, 4013);
                settingslist->InsertTab(2, L"SettingsPage3", pszBuf, ShowPage3);
            }
            settingslist->TraversePage(0);
            settingslist->SetKeyFocus();
        }
    }

    void InitSubview()
    {
        RECT dimensions;
        SystemParametersInfoW(SPI_GETWORKAREA, sizeof(dimensions), &dimensions, NULL);

        DWORD dwExStyle = WS_EX_TOOLWINDOW, dwCreateFlags = 0x10;
        if (g_pctx->DWMActive)
        {
            dwExStyle |= WS_EX_LAYERED | WS_EX_NOREDIRECTIONBITMAP;
            dwCreateFlags |= 0x28;
        }
        NativeHWNDHost::Create(L"DD_SubviewHost", L"DirectDesktop Subview", nullptr, nullptr, dimensions.left, dimensions.top, 9999, 9999, dwExStyle, WS_POPUP, nullptr, 0x43, &subviewwnd);
        DUIXmlParser::Create(&parserSubview, nullptr, nullptr, DUI_ParserErrorCB, nullptr);
        parserSubview->SetXMLFromResource(IDR_UIFILE3, HINST_THISCOMPONENT, HINST_THISCOMPONENT);
        HWNDElement::Create(subviewwnd->GetHWND(), true, dwCreateFlags, nullptr, &key2, (Element**)&subviewparent);
        WndProcSubview = (WNDPROC)SetWindowLongPtrW(subviewwnd->GetHWND(), GWLP_WNDPROC, (LONG_PTR)TopLevelWindowProc);

        CLIPFORMAT cf_list[1] = { CF_HDROP };
        HWND hwndInner = FindWindowExW(subviewwnd->GetHWND(), nullptr, L"DirectUIHWND", nullptr);
        WndProcSubviewInner = (WNDPROC)SetWindowLongPtrW(hwndInner, GWLP_WNDPROC, (LONG_PTR)InnerWindowProc2);
        g_subviewtarget = MyRegisterDragDrop(hwndInner, cf_list, 1, WM_NULL, TheDropProc, NULL);
        g_subviewtarget->SetSubviewFlag();

        parserSubview->CreateElement(L"fullscreenpopup", subviewparent, nullptr, nullptr, &pSubview);
        pSubview->SetVisible(true);
        pSubview->EndDefer(key2);

        fullscreenpopupbg = regElem(L"fullscreenpopupbg", pSubview);
        fullscreenpopupbase = (TouchButton*)regElem(L"fullscreenpopupbase", pSubview);
        popupcontainer = regElem(L"popupcontainer", pSubview);
        centered = (TouchButton*)regElem(L"centered", pSubview);

        if (g_pctx->DWMActive)
        {
            AddLayeredRef(fullscreenpopupbg->GetDisplayNode());
            SetGadgetFlags(fullscreenpopupbg->GetDisplayNode(), NULL, NULL);
        }

        assignFn(fullscreenpopupbase, testEventListener3);

        subviewwnd->Host(pSubview);
        MARGINS m = { -1, -1, -1, -1 };
        if (g_pctx->DWMActive) DwmExtendFrameIntoClientArea(subviewwnd->GetHWND(), &m);
    }
}
