#include "pch.h"

#include "SearchPage.h"
#include "..\DirectDesktop.h"
#include "..\backend\DirectoryHelper.h"

#ifdef HAS_SEARCH
#include "EverythingSearch/Everything.h"
#pragma comment (lib, "Everything64.lib")
#endif

using namespace DirectUI;
using namespace DDUI;

namespace DirectDesktop
{
    NativeHWNDHost* searchwnd;
    DUIXmlParser* parserSearch;
    HWNDElement* parentSearch;
    Element* pSearch;
    DDScalableTouchEdit* searchbox;
    WNDPROC WndProcSearch;

    DWORD WINAPI AnimateSearchWindow(LPVOID lpParam);
    void DestroySearchPage();

    // 0.5.8.1: TODO: Better peek listener
    LRESULT CALLBACK SearchWindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
    {
        switch (uMsg)
        {
            case WM_CLOSE:
                SetTimer(hWnd, 1, 50, nullptr);
                return 0;
            case WM_DESTROY:
                return 0;
            case WM_CANCELMODE:
            {
                if (!g_peek)
                {
                    g_peek = true;
                    GTRANS_DESC transDesc[1];
                    TransitionStoryboardInfo tsbInfo = {};
                    TriggerScaleOut(UIContainer, transDesc, 0, 0.0f, 0.5f, 0.1f, 0.9f, 0.2f, 1.0f, 1.0f, 1.0f, 0.5f, 0.5f, false, false);
                    ScheduleGadgetTransitions_DWMCheck(0, ARRAYSIZE(transDesc), transDesc, UIContainer->GetDisplayNode(), &tsbInfo);
                    DUI_SetGadgetZOrder(UIContainer, -1);
                }
                break;
            }
            case WM_NCHITTEST:
            {
                if (g_peek)
                {
                    g_peek = false;
                    GTRANS_DESC transDesc[1];
                    TransitionStoryboardInfo tsbInfo = {};
                    TriggerScaleOut(UIContainer, transDesc, 0, 0.0f, 0.67f, 0.1f, 0.9f, 0.2f, 1.0f, 0.92f, 0.92f, 0.5f, 0.5f, false, false);
                    ScheduleGadgetTransitions_DWMCheck(0, ARRAYSIZE(transDesc), transDesc, UIContainer->GetDisplayNode(), &tsbInfo);
                    if (g_pctx->windowAnim && g_pctx->clientAnim)
                    {
                        CSafeElementPtr<Element> pagecontent;
                        pagecontent.Assign(regElem(L"pagecontent", pSearch));
                        pagecontent->SetVisible(false);
                        TriggerScaleIn(pagecontent, transDesc, 0, 0.05f, 0.3f, 0.25f, 0.1f, 0.25f, 1.0f, 0.97f, 0.97f, 0.5f, 0.5f, 1.0f, 1.0f, 0.5f, 0.5f, true, false);
                        ScheduleGadgetTransitions_DWMCheck(0, ARRAYSIZE(transDesc), transDesc, nullptr, &tsbInfo);
                        AnimateWindow(hWnd, 10, AW_BLEND | AW_HIDE);
                        HANDLE AnimHandle = CreateThread(nullptr, 0, AnimateSearchWindow, nullptr, NULL, nullptr);
                        if (AnimHandle) CloseHandle(AnimHandle);
                    }
                }
                break;
            }
            case WM_NCACTIVATE:
            {
                if (wParam == 0)
                {
                    HWND hForeground = GetForegroundWindow();
                    if (!hForeground)
                    {
                        HWND hTrayNotify = FindWindowExW(g_hWndTaskbar, nullptr, L"TrayNotifyWnd", nullptr);
                        HWND hShowDesktop = FindWindowExW(hTrayNotify, nullptr, L"TrayShowDesktopButtonWClass", nullptr);
                        RECT rc;
                        POINT pt;
                        GetWindowRect(hShowDesktop, &rc);
                        GetCursorPos(&pt);
                        if (PtInRect(&rc, pt))
                        {
                            g_peek = false;
                            DestroySearchPage();
                        }
                    }
                }
                break;
            }
            case WM_TIMER:
                KillTimer(hWnd, wParam);
                switch (wParam)
                {
                case 1:
                    DestroySearchPage();
                    break;
                }
            case WM_USER + 1:
            {
                searchbox->SetKeyFocus();
                break;
            }
        }
        return CallWindowProc(WndProcSearch, hWnd, uMsg, wParam, lParam);
    }

    DWORD WINAPI AnimateSearchWindow(LPVOID lpParam)
    {
        DWORD animCoef = g_pctx->animCoef;
        if (g_pctx->AnimShiftKey && !(GetAsyncKeyState(VK_SHIFT) & 0x8000)) animCoef = 100;
        if (g_pctx->windowAnim && g_pctx->clientAnim)
            AnimateWindow(searchwnd->GetHWND(), 150 * (animCoef / 100.0f), AW_BLEND);
        else
            searchwnd->ShowWindow(SW_SHOW);
        SendMessageW(searchwnd->GetHWND(), WM_USER + 1, NULL, NULL);
        return 0;
    }

    DWORD WINAPI AnimateSearchWindow2(LPVOID lpParam)
    {
        DWORD animCoef = g_pctx->animCoef;
        if (g_pctx->AnimShiftKey && !(GetAsyncKeyState(VK_SHIFT) & 0x8000)) animCoef = 100;
        if (!g_pctx->windowAnim || !g_pctx->clientAnim) animCoef = 0;
        Sleep(175 * (animCoef / 100.0f));
        SetForegroundWindow(wnd->GetHWND());
        if (g_pctx->windowAnim && g_pctx->clientAnim)
            AnimateWindow(searchwnd->GetHWND(), 120 * (animCoef / 100.0f), AW_BLEND | AW_HIDE);
        else
            searchwnd->ShowWindow(SW_HIDE);
        searchwnd->DestroyWindow();
        g_searchopen = false;
        return 0;
    }

    void LaunchSearchResult(Element* elem, Event* iev)
    {
        if (iev->uidType == TouchButton::Click)
        {
            wstring temp = ((LVItem*)elem)->GetFilename();
            SHELLEXECUTEINFOW execInfo = {};
            execInfo.cbSize = sizeof(SHELLEXECUTEINFOW);
            execInfo.lpVerb = L"open";
            execInfo.nShow = SW_SHOWNORMAL;
            execInfo.lpFile = temp.c_str();
            ShellExecuteExW(&execInfo);
        }
    }

    void DisplayResults(Element* elem, Event* iev)
    {
        static LPWSTR path{};
        GetRegistryStrValues(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\User Shell Folders", L"Desktop", &path);
        if (iev->uidType == TouchButton::Click || iev->uidType == TouchButton::MultipleClick)
        {
            MessageBeep(MB_OK);
            //CValuePtr v;
            //if (wcslen(searchbox->GetContentString(&v)) < 2) return;
            //WCHAR* PublicPath = new WCHAR[260];
            //WCHAR* OneDrivePath = new WCHAR[260];
            //WCHAR* cBuffer = new WCHAR[260];
            //DWORD d = GetEnvironmentVariableW(L"PUBLIC", cBuffer, 260);
            //StringCchPrintfW(PublicPath, 260, L"%s\\Desktop", cBuffer);
            //d = GetEnvironmentVariableW(L"OneDrive", cBuffer, 260);
            //StringCchPrintfW(OneDrivePath, 260, L"%s\\Desktop", cBuffer);
            CSafeElementPtr<Element> rescontainer;
            rescontainer.Assign(regElem(L"rescontainer", pSearch));
            //rescontainer->DestroyAll(true);
            //WCHAR* searchquery = new WCHAR[1024];
            //StringCchPrintfW(searchquery, 1024, L"%s | %s | %s %s", path, PublicPath, OneDrivePath, searchbox->GetContentString(&v));
            //Everything_SetSearchW(searchquery);
            //Everything_QueryW(TRUE);
            //delete[] searchquery;
            //delete[] cBuffer;
            //delete[] PublicPath;
            //delete[] OneDrivePath;
            //LVItem* SearchResultPlaceholder{};
            //parserSearch->CreateElement(L"SearchResult", NULL, NULL, NULL, (Element**)&SearchResultPlaceholder);
            RichText* ResultCount{};
            parserSearch->CreateElement(L"ResultCount", nullptr, nullptr, nullptr, (Element**)&ResultCount);
            rescontainer->Add((Element**)&ResultCount, 1);
            //WCHAR* resultc = new WCHAR[64];
            //StringCchPrintfW(resultc, 64, L"%d items", Everything_GetNumResults());
            MessageBeep(MB_OK);
            DDNotificationBanner* ddnb = new DDNotificationBanner();
            ddnb->CreateBanner(DDNT_INFO, nullptr, L"Search will be available by version 0.6", 5);
            //rescontainer->SetHeight(Everything_GetNumResults() * SearchResultPlaceholder->GetHeight() + 40);
            //for (int i = 0; i < Everything_GetNumResults(); i++) {
            //	WCHAR* nameStr = new WCHAR[256];
            //	WCHAR* pathStr = new WCHAR[256];
            //	StringCchPrintfW(nameStr, 256, L"NAME: %s", Everything_GetResultFileNameW(i));
            //	StringCchPrintfW(pathStr, 256, L"PATH: %s", Everything_GetResultPathW(i));
            //	LVItem* SearchResult{};
            //	parserSearch->CreateElement(L"SearchResult", NULL, NULL, NULL, (Element**)&SearchResult);
            //	rescontainer->Add((Element**)&SearchResult, 1);
            //	RichText* name = regElem(L"name", SearchResult);
            //	RichText* path = regElem(L"path", SearchResult);
            //	name->SetContentString(nameStr);
            //	path->SetContentString(pathStr);
            //	SearchResult->SetFilename((wstring)Everything_GetResultPathW(i) + L"\\" + Everything_GetResultFileNameW(i));
            //	assignFn(SearchResult, LaunchSearchResult);
            //	delete[] nameStr;
            //	delete[] pathStr;
            //}
            //delete[] resultc;
            //free(SearchResultPlaceholder);
        }
    }

    void CloseSearch(Element* elem, Event* iev)
    {
        if (iev->uidType == TouchButton::Click)
        {
            SetTimer(searchwnd->GetHWND(), 1, 50, nullptr);
        }
    }

    void CreateSearchPage(bool WinAltQ)
    {
        if (g_searchopen) return;
        if (WinAltQ) SendMessageW(g_hWndTaskbar, WM_COMMAND, 419, 0);
        g_searchopen = true;
        unsigned long key4 = 0;
        RECT dimensions;
        SystemParametersInfoW(SPI_GETWORKAREA, sizeof(dimensions), &dimensions, NULL);
        static IElementListener* pel_DisplayResults, * pel_CloseSearch;
        DWORD dwExStyle = WS_EX_TOOLWINDOW, dwCreateFlags = 0x10;
        if (g_pctx->DWMActive)
        {
            dwExStyle |= WS_EX_LAYERED | WS_EX_NOREDIRECTIONBITMAP;
            dwCreateFlags |= 0x28;
        }
        NativeHWNDHost::Create(L"DD_SearchHost", L"DirectDesktop Everything Search Wrapper", nullptr, nullptr,
            dimensions.left, dimensions.top, dimensions.right - dimensions.left, dimensions.bottom - dimensions.top, dwExStyle, WS_POPUP, nullptr, 0x43, &searchwnd);
        DUIXmlParser::Create(&parserSearch, nullptr, nullptr, DUI_ParserErrorCB, nullptr);
        parserSearch->SetXMLFromResource(IDR_UIFILE5, HINST_THISCOMPONENT, HINST_THISCOMPONENT);
        HWNDElement::Create(searchwnd->GetHWND(), true, dwCreateFlags, nullptr, &key4, (Element**)&parentSearch);
        parserSearch->CreateElement(L"SearchUI", parentSearch, nullptr, nullptr, &pSearch);
        WndProcSearch = (WNDPROC)SetWindowLongPtrW(searchwnd->GetHWND(), GWLP_WNDPROC, (LONG_PTR)SearchWindowProc);
        pSearch->SetVisible(true);
        pSearch->EndDefer(key4);
        CSafeElementPtr<Element> searchbase;
        searchbase.Assign(regElem(L"searchbase", pSearch));
        LPWSTR sheetName = g_pctx->theme ? (LPWSTR)L"searchstyle" : (LPWSTR)L"searchstyledark";
        StyleSheet* sheet = pSearch->GetSheet();
        CValuePtr sheetStorage = DirectUI::Value::CreateStyleSheet(sheet);
        parserSearch->GetSheet(sheetName, &sheetStorage);
        pSearch->SetValue(Element::SheetProp, 1, sheetStorage);
        searchbox = (DDScalableTouchEdit*)regElem(L"searchbox", pSearch);
        free(pel_DisplayResults), free(pel_CloseSearch);
        CSafeElementPtr<DDScalableTouchButton> searchbutton;
        searchbutton.Assign((DDScalableTouchButton*)regElem(L"searchbutton", pSearch));
        pel_DisplayResults = (IElementListener*)assignFn(searchbutton, DisplayResults, true);
        CSafeElementPtr<DDScalableTouchButton> closebutton;
        closebutton.Assign((DDScalableTouchButton*)regElem(L"closebutton", pSearch));
        pel_CloseSearch = (IElementListener*)assignFn(closebutton, CloseSearch, true);
        CSafeElementPtr<TouchScrollViewer> SearchResults;
        SearchResults.Assign((TouchScrollViewer*)regElem(L"SearchResults", pSearch));
        CSafeElementPtr<Element> pagecontent;
        pagecontent.Assign(regElem(L"pagecontent", pSearch));
        searchwnd->Host(pSearch);
        searchwnd->ShowWindow(SW_HIDE);
        GTRANS_DESC transDesc[1];
        TriggerScaleOut(UIContainer, transDesc, 0, 0.0f, 0.67f, 0.1f, 0.9f, 0.2f, 1.0f, 0.92f, 0.92f, 0.5f, 0.5f, false, false);
        TransitionStoryboardInfo tsbInfo = {};
        ScheduleGadgetTransitions_DWMCheck(0, ARRAYSIZE(transDesc), transDesc, UIContainer->GetDisplayNode(), &tsbInfo);
        GTRANS_DESC transDesc2[2];
        TriggerFade(pagecontent, transDesc2, 0, 0.05f, 0.18f, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f, true, false, false);
        TriggerScaleIn(pagecontent, transDesc2, 1, 0.05f, 0.72f, 0.1f, 0.9f, 0.2f, 1.0f, 0.75f, 0.75f, 0.5f, 0.5f, 1.0f, 1.0f, 0.5f, 0.5f, false, false);
        ScheduleGadgetTransitions_DWMCheck(0, ARRAYSIZE(transDesc2), transDesc2, pagecontent->GetDisplayNode(), &tsbInfo);
        MARGINS m = { -1, -1, -1, -1 };
        if (g_pctx->DWMActive)
        {
            AddLayeredRef(searchbase->GetDisplayNode());
            SetGadgetFlags(searchbase->GetDisplayNode(), NULL, NULL);
            AddLayeredRef(pagecontent->GetParent()->GetDisplayNode());
            SetGadgetFlags(pagecontent->GetParent()->GetDisplayNode(), NULL, NULL);
            DwmExtendFrameIntoClientArea(searchwnd->GetHWND(), &m);
        }
        HANDLE AnimHandle = CreateThread(nullptr, 0, AnimateSearchWindow, nullptr, NULL, nullptr);
        if (AnimHandle) CloseHandle(AnimHandle);
        BlurBackground(searchwnd->GetHWND(), true, true, 0x99, searchbase);
    }

    void DestroySearchPage()
    {
        GTRANS_DESC transDesc[1];
        TriggerScaleOut(UIContainer, transDesc, 0, 0.175f, 0.675f, 0.1f, 0.9f, 0.2f, 1.0f, 1.0f, 1.0f, 0.5f, 0.5f, false, false);
        TransitionStoryboardInfo tsbInfo = {};
        ScheduleGadgetTransitions_DWMCheck(0, ARRAYSIZE(transDesc), transDesc, UIContainer->GetDisplayNode(), &tsbInfo);
        DUI_SetGadgetZOrder(UIContainer, -1);
        CSafeElementPtr<Element> pagecontent;
        pagecontent.Assign(regElem(L"pagecontent", pSearch));
        GTRANS_DESC transDesc2[2];
        TriggerScaleOut(pagecontent, transDesc2, 0, 0.0f, 0.175f, 1.0f, 1.0f, 0.0f, 1.0f, 0.95f, 0.95f, 0.5f, 0.5f, false, false);
        TriggerFade(pagecontent, transDesc2, 1, 0.0f, 0.15f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f, 0.0f, true, false, true);
        ScheduleGadgetTransitions_DWMCheck(0, ARRAYSIZE(transDesc2), transDesc2, pagecontent->GetDisplayNode(), &tsbInfo);
        SendMessageW(g_hWndTaskbar, WM_COMMAND, 416, 0);
        DWORD animThread;
        HANDLE animThreadHandle = CreateThread(nullptr, 0, AnimateSearchWindow2, nullptr, 0, &animThread);
        if (animThreadHandle) CloseHandle(animThreadHandle);
    }
}
