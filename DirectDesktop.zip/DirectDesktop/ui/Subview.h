#pragma once

#include "..\DirectDesktop.h"
#include "..\backend\DragAndDrop.h"

using namespace DirectUI;
using namespace DDUI;

namespace DirectDesktop
{
	extern TEXTMETRICW textm;
	extern int g_lastDpiChangeTick;
	extern int g_settingsPageID;
	extern int g_touchSizeX, g_touchSizeY;
	extern BYTE iconColorID;
	extern COLORREF IconColorizationColor;
	extern bool g_delayGroupsForDpi;
	extern bool g_ignoreWorkAreaChange;
	extern bool g_checkifelemexists;
	extern bool g_issubviewopen;
	extern bool g_issettingsopen;
	extern BYTE* shellstate;

	extern void AdjustWindowSizes(bool firsttime);
	extern void CalcDesktopIconInfo(yValue* yV, int* lines_basedOnEllipsis, DWORD* alignment, bool subdirectory, vector<LVItem*>* pmLVItem);
	extern void ApplyIcons(vector<LVItem*>* pmLVItem, DesktopIcon* di, bool subdirectory, int id, float scale, COLORREF crSubdir);
	extern void ShowDebugInfoOnDesktop(bool bUnused1, bool bUnused2, bool bUnused3);

	extern void OpenGroupInExplorer(Element* elem, Event* iev);
	extern void CloseCustomizePage(Element* elem, Event* iev);
	extern void OpenCustomizePage(Element* elem, Event* iev);
	extern void PinGroup(Element* elem, Event* iev);
	extern void UpdateIconColorizationColor(Element* elem, const PropertyInfo* pProp, int type, Value* pV1, Value* pV2);

	extern NativeHWNDHost* wnd;
	extern DDScalableElement* RegistryListener;
	extern TouchButton* fullscreenpopupbase;
	extern DDScalableTouchButton* fullscreeninner;
	extern TouchButton* centered;
	extern NativeHWNDHost* subviewwnd;
	extern DUIXmlParser* parserSubview;
	extern Element* pSubview;

	extern HMODULE g_hModTWinUI;
	extern CDropTarget* g_subviewtarget;

	void ShowPopupCore(Element** ppeAnimateFrom);
	void HidePopupCore(bool WinDInvoked, bool fNoRefresh);
	void InitSubview();

	void ShowDirAsGroup(LVItem** pplvi);
	void SetDefaultRes(Element* elem, Event* iev);
	void SelectSubItem(Element* elem, Event* iev);
	void SelectSubItemListener(Element* elem, const PropertyInfo* pProp, int type, Value* pV1, Value* pV2);

	DWORD WINAPI subfastin(LPVOID lpParam);
	extern DWORD WINAPI RearrangeIconsHelper(LPVOID lpParam);
}